Players = {}
teams = []


def battingPoints(runScored, ballFaced):
    points = 0
    if runScored == 0:
        points = points - 10
    else:
        points = points + runScored
        points = points + (runScored / 25) * 10
    strikeRate = runScored / ballFaced
    if(strikeRate == 0):
        points = points - 10
    else:
        points = points + 10
    return points


def bowlingPoints(wicketsTaken, ballsBowled):
    points = 0
    if wicketsTaken == 0 and ballsBowled >= 1:
        points = points - 10
    if wicketsTaken >= 1:
        points = points + 20
        points = points + (wicketsTaken - 1) * 10
    return points


def getpoints(player):
    runScored = Players[player][0]
    ballFaced = Players[player][1]
    wicketsTaken = Players[player][2]
    ballsBowled = Players[player][3]
    points = 0
    points = points + \
        battingPoints(runScored, ballFaced) + \
        bowlingPoints(wicketsTaken, ballsBowled)
    return points


def getAverage(players):
    sum = 0
    for player in players:
        sum = sum + Players[player][0]
    average = float(sum) / len(players)
    return average


def finalEval(players):
    points = 0
    average = getAverage(players)
    for player in players:
        if Players[player][0] >= average:
            points = points + 15
        else:
            points = points - 15
    #print (points)
    return points


inputLine = list(map(int, input().split(" ")))
n = inputLine[0]
m = inputLine[1]
#print (n, m)

for x in range(n):
    inputLine = input().split(" ")
    Players[inputLine[0]] = list(map(int, inputLine[1:]))

for x in range(2):
    team = {}
    team["players"] = input().split(" ")
    team["points"] = 0
    teams.append(team)


for team in teams:
    points = team["points"]
    for player in team["players"]:
        points = points + getpoints(player)
    points = points + finalEval(team["players"])
    team["points"] = points

#print (teams)

if teams[0]["points"] == teams[1]["points"]:
    print ("DRAW")
elif teams[0]["points"] > teams[1]["points"]:
    print ("FANTASY TEAM ONE")
else:
    print ("FANTASY TEAM TWO")
