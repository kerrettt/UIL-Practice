values = input()
pollution_limits = []
values = values.split(" ")
for i in range(0,4):
	pollution_limits.append(int(values[i]))

companies = [] 
for i in range(0,4):
	temp = input()
	zone = temp.split(" ")
	no_of_companies = int(zone[0])
	values = []
	for i in range(no_of_companies):
		values.append(int(zone[i+1]))
	values.sort()
	companies.append(values)

for i in range(0,4):
	threshold = pollution_limits[i]
	values = companies[i]
	output = []
	no = 0
	output.append(no)
	while(threshold>0 and values):
		company_index = values.pop(0)
		threshold = threshold - company_index
		if(threshold >= 0):
			output.append(company_index)
			no+=1
		else:
			break
	output[0] = no		
	print(*output,sep=" ")


