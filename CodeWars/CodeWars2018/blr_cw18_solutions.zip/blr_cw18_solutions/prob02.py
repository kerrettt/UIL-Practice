import sys
# Accept a integer from User
n = int(input())
# Print the number of Edges
print( int(n*(n-1)/2))
