'''
   :platform : Windows, Linux

    ..moduleauthor :: Suraj S

    Finds the smallest Wait time from the data Provided
'''
# Read from IO
data = []
route_name = []
time_limit = int(raw_input())
test_case = int(raw_input())
while test_case > 0:
    input_list = raw_input().split()
    route_name.append(input_list[0])
    #print "route_name:", input_list[0]
    #print input_list
    input_list.pop(0)
    input_list.pop(0)
    #print input_list
    pit_stops = map(int, input_list)
    #pit_stops.pop(0)
    # Find the Wait Time
    exp = time_limit - sum(pit_stops)
    #print "exp: ", exp
    data.append(exp)
    test_case -= 1
# Find the smallest Wait time if Rahul arrives before Time
exp = min((i for i in data if i >= 0))
# Enjoy!!!, Your Program is done
#print data.index(exp) + 1
#print data
print
print route_name[data.index(exp)]
