import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 * Team building exercise at Taj Vivanta
 * @author Vaishnavi Mathavan
 * Copyright HPE @ 2018
 */

/**
 * Main class to get user inputs and show output
 * Inputs: 
 * num of employees 
 * retreat's duration in days
 * Supervisor ids of all employees
 * Amount allocated for each group
 * Max grouping size
 * Output: minimum total cost for the M-day retreat
 */

public class prob12 
{
	static int maxGrpSize;
	Set<LinkedHashSet<Integer>> tempAssignList;
	static int totalTreatAmt;
	static POJO pojo = new POJO();

	public static void main(String args[])
	{
		Scanner ip = new Scanner(System.in);

		ArrayList<Integer> managers = new ArrayList<>();
		Map<Integer,Integer> repMgrMap = new HashMap<>();
		ArrayList<Integer> tempList;
		Map<Integer,ArrayList<Integer>> mgrReportMap = new LinkedHashMap<>();
		int tempGrpAmt;
		
		////System.out.println("Enter num of employees and retreat's duration in days");
		int nEmp = ip.nextInt();
		int treatDays = ip.nextInt();

		////System.out.println("Employee id: 1 is MD. No supervisor for MD");
		//System.out.println("Enter the corresponding supervisor: (Starting from employee 2)");
		int[] supvArr = new int[nEmp - 1];
		for(int i = 0; i < nEmp - 1; i++)
		{
			supvArr[i] = ip.nextInt();
		}
		for(int i = 1; i <= nEmp; i++)
		{
			tempList = new ArrayList<>();
			for(int j = 0; j < nEmp - 1; j++)
			{
				if(supvArr[j] == i)
				{
					tempList.add(j+2);
					repMgrMap.put(j+2, i);
				}
			}
			managers.add(i);
			mgrReportMap.put(i, tempList);
		}
		//System.out.println(mgrReportMap);

		pojo.setMgrReporteeMap(mgrReportMap);

		int amtForGrp[] = new int[treatDays];
		int grpSizeArr[] = new int[treatDays];

		//System.out.println("Enter Amount allocated for each group and max grouping size");
		for(int num = 0; num < treatDays; num++)
		{
			amtForGrp[num] = ip.nextInt();
			grpSizeArr[num] = ip.nextInt();
		}

		for(int n = 0; n < treatDays; n++)
		{
			maxGrpSize = grpSizeArr[n];
			pojo.setMaxGrpSize(maxGrpSize);

			for(int i = 0; i < managers.size(); i++)
			{
				for(int j = i; j < managers.size(); j++)
				{

					int start = managers.get(j);

					if(start == 1)
						pojo.addEmpToGroup(start, 0);
					else
						pojo.addEmpToGroup(start, repMgrMap.get(start));

					if(maxGrpSize >= 1)
					{	
						List<Integer> childList = pojo.getChildList(start);
						addMgrOneReportee(mgrReportMap, start, childList);
					}
				}

				for (int j = 0; j < i; j++)
				{
					int start = managers.get(j);
					if(start == 1)
						pojo.addEmpToGroup(start, 0);
					else
						pojo.addEmpToGroup(start, repMgrMap.get(start));

					if(maxGrpSize >= 1)
					{	
						List<Integer> childList = pojo.getChildList(start);
						addMgrOneReportee(mgrReportMap, start, childList);
					}
				}

				//System.out.println("After " + (i + 1) + " iteration :" + pojo.getFormedGroup());

				pojo.setFormedGroupSize();
				pojo.clearFormedGroup();
			}
			tempGrpAmt = pojo.getFormedGroupSize() * amtForGrp[n];
			//System.out.println("Amount needed for " + maxGrpSize + " member group is : " + tempGrpAmt);
			totalTreatAmt += tempGrpAmt;
			pojo.clearFormedGroupSize();
		}
		//System.out.println("Minimum total cost for the" + treatDays +"-day retreat: " + totalTreatAmt);
		System.out.println(totalTreatAmt);
		ip.close();
	}

	/**
	 * Add employee to group that is less than max group size
	 * @param mgrReportMap
	 * @param start
	 * @param childList
	 * @return
	 */
	private static void addMgrOneReportee(Map<Integer, ArrayList<Integer>> mgrReportMap, 
			int start, List<Integer> childList) 
	{
		for(int i = childList.size() - 1; i >= 0; i--)
		{
			pojo.addEmpToGroup(childList.get(i), start);
		}
	}
}
