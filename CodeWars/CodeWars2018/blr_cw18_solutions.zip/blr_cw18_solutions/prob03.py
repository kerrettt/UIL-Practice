'''
   platform : Windows, Linux

   author :: Rajeev Kallur
    
   Objective: A program to find out the total number of jumps
               terrorist has to make to escape from Yerwada Jail
'''
#print ("Height Terrorist can jump(X): ")
in1 = input().split(' ')
x = int(in1[0])
#print (x)

#print ("Length Terrorist slips back after each jump(Y): ")
y = int(in1[1])
#print (y)

#print ("Number of walls: ")
in2 = input().split(' ')
N = int(in2[0])
#print (N)
WallHeights = []

for i in range(len(in2) - 1):
        WallHeights.append(in2[i+1])

#print (WallHeights, len(WallHeights))

if ((N == 1) and (int(WallHeights[0]) <= x)):
	print ("1")
	exit()

if (y>=x):
        #print ('A')
        print ("-1")
        exit()

if (len(WallHeights)!=N):
        #print ('B')
        print("-1")
        exit()

jumpsRequired = 0

for H in WallHeights:
        height = int(H)
        jumpsRequired+=1
        while (height > x):
                jumpsRequired+=1
                height=height-(x-y)

print (jumpsRequired)
