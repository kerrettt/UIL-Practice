'''
   :platform : Windows, Linux

    ..moduleauthor :: Suraj S, Rajeev Kallur

    Prints the Number of Weekday present in a Calender Month
'''
import calendar
# Dictionaries which contain Days, Months & their respective Integer equivalent
day_dict = {"MONDAY": 0, "TUESDAY": 1, "WEDNESDAY": 2, "THURSDAY": 3,  "FRIDAY": 4, "SATURDAY": 5, "SUNDAY": 6}
month_dict = {"JANUARY": 1, "FEBRUARY": 2, "MARCH": 3, "APRIL": 4, "MAY": 5, "JUNE": 6, "JULY": 7, "AUGUST": 8, "SEPTEMBER": 9, "OCTOBER": 10, "NOVEMBER": 11, "DECEMBER": 12}

# Create a Object of Calender Class
abc = calendar.Calendar()
# Input from STDIN : Month <str>, Year <str>, Weekday <str>
in1 = input().split(' ')
month = in1[0]
year = int(in1[1])
day = in1[2]
if year == 0:
    print("Invalid input")
    exit()
# Tracks the count of the Weekday
count = 0
for data in abc.monthdayscalendar(year, month_dict[month]):
    if data[day_dict[day]]:
        count += 1
print (count)
