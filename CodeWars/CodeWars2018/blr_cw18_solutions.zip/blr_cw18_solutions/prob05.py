import sys

winner = {"weight": -1, "sequence": None}
weights = {"A": 36, "K": 13, "Q": 12, "J": 11, "10": 10, "9": 9, "8": 8, "7": 7, "6": 6, "5": 5, "4": 4, "3": 3, "2": 2, "1": 1}
points = {"triplet": 100000, "pure_s": 10000, "seq": 1000, "color": 100, "pair": 10}
priority = {"C": 1000, "D": 100, "H": 10, "S": 1}

def is_triplet(c1, c2, c3):
    return weights[c1] == weights[c2] == weights[c3]

def is_sequence(c1, c2, c3):
    c = [c1, c2, c3]
    if weights[c1] == 2*(weights[c2] + weights[c3]) or weights[c2] == 2*(weights[c1] + weights[c3]) or weights[c3] == 2*(weights[c2] + weights[c1]) :
        return True
    elif "A" in c and "K" in c and "Q" in c:
        return True
    elif "A" in c and "2" in c and "3" in c:
        return True
    return False

def isPair(c1, c2, c3, card1, card2, card3):
    if weights[c1] == weights[c2]:
        if card1 == card2:
            raise Exception("INVALID INPUT")
        else:
            return True
    elif weights[c2] == weights[c3]:
        if card2 == card3:
            raise Exception("INVALID INPUT")
        else:
            return True
    elif weights[c1] == weights[c3]:
        if card1 == card3:
            raise Exception("INVALID INPUT")
        else:
            return True
    return False

def is_color(c1, c2, c3):
    return c1 == c2 == c3

def high_card(c1, c2, c3):
    return max([weights[c1], weights[c2], weights[c3]])

def get_priority(card1, card2, card3):
    c_weight = high_card(card1[1:], card2[1:], card3[1:])

    if weights[card1[1:]] == c_weight:
        return priority[card1[0]]
    if weights[card2[1:]] == c_weight:
        return priority[card2[0]]
    if weights[card3[1:]] == c_weight:
        return priority[card3[0]]

def main():
    i = 0
    t = int(input())

    while(i < t):
        cards = str(input())
        cards = cards.split()

        try:
            [c1, c2, c3] = [cards[0][1:], cards[1][1:], cards[2][1:]]

            if weights[c1] is None or weights[c2] is None or weights[c3] is None:
                raise KeyError("INVALID INPUT")
            if priority[cards[0][0]] is None or priority[cards[1][0]] is None or priority[cards[2][0]] is None :
                raise KeyError("INVALID INPUT")

            if is_triplet(c1, c2, c3):
                if cards[0][0] == cards[1][0] or cards[1][0] == cards[2][0] or cards[1][0] == cards[2][0]:
                    raise Exception("INVALID INPUT")
                if winner["weight"] <  3*weights[c1]*points["triplet"]:
                    winner["weight"] = 3*weights[c1]*points["triplet"]
                    winner["sequence"] = " ".join(c for c in cards)
                elif winner["weight"] == 3*weights[c1]*points["triplet"]:
                    current_priority = None
                    next_priority = None
                    if next_priority > current_priority:
                        winner["weight"] = 3*weights[c1]*points["triplet"]
                        winner["sequence"] = " ".join(c for c in cards)

            elif is_sequence(c1, c2, c3):
                if is_color(cards[0][0], cards[1][0], cards[2][0]):
                    if winner["weight"] <  (weights[c1] + weights[c2] + weights[c3])*(points["pure_s"]):
                        winner["weight"] = (weights[c1] + weights[c2] + weights[c3])*(points["pure_s"])
                        winner["sequence"] = " ".join(c for c in cards)
                    elif winner["weight"] == (weights[c1] + weights[c2] + weights[c3])*(points["pure_s"]):
                        win_cards = winner["sequence"].split()
                        current_priority = get_priority(win_cards[0], win_cards[1], win_cards[2])
                        next_priority = get_priority(cards[0], cards[1], cards[2])
                        if next_priority > current_priority:
                            winner["weight"] = (weights[c1] + weights[c2] + weights[c3])*(points["pure_s"])
                            winner["sequence"] = " ".join(c for c in cards)
                else:
                    if winner["weight"] < (weights[c1] + weights[c2] + weights[c3])*(points["seq"]):
                        winner["weight"] = (weights[c1] + weights[c2] + weights[c3])*(points["seq"])
                        winner["sequence"] = " ".join(c for c in cards)
                    elif winner["weight"] == (weights[c1] + weights[c2] + weights[c3])*(points["seq"]):
                        win_cards = winner["sequence"].split()
                        current_priority = get_priority(win_cards[0], win_cards[1], win_cards[2])
                        next_priority = get_priority(cards[0], cards[1], cards[2])
                        if next_priority > current_priority:
                            winner["weight"] = (weights[c1] + weights[c2] + weights[c3])*(points["seq"])
                            winner["sequence"] = " ".join(c for c in cards)

            elif is_color(cards[0][0], cards[1][0], cards[2][0]):
                if c1 == c2 or c2 == c3 or c1 == c3:
                    raise Exception("INVALID INPUT")

                if winner["weight"] < (weights[c1] + weights[c2] + weights[c3])*(points["color"]):
                    winner["weight"] = (weights[c1] + weights[c2] + weights[c3])*(points["color"])
                    winner["sequence"] = " ".join(c for c in cards)
                elif winner["weight"] == (weights[c1] + weights[c2] + weights[c3])*(points["color"]):
                    win_cards = winner["sequence"].split()
                    current_priority = get_priority(win_cards[0], win_cards[1], win_cards[2])
                    next_priority = get_priority(cards[0], cards[1], cards[2])
                    if current_priority > next_priority:
                        winner["weight"] = (weights[c1] + weights[c2] + weights[c3])*(points["color"])
                        winner["sequence"] = " ".join(c for c in cards)

            elif isPair(c1, c2, c3, cards[0][0], cards[1][0], cards[2][0]):
                if winner["weight"] < (weights[c1] + weights[c2] + weights[c3])*points["pair"]:
                    winner["weight"] = weights[c1] + weights[c2] + weights[c3]
                    winner["sequence"] = " ".join(c for c in cards)
            else:
                high_weight = high_card(c1, c2, c3)
                if winner["weight"] < high_weight:
                    winner["weight"] = high_weight
                    winner["sequence"] = " ".join(c for c in cards)
                elif winner["weight"] == high_weight:
                    win_cards = winner["sequence"].split()
                    current_priority = get_priority(win_cards[0], win_cards[1], win_cards[2])
                    next_priority = get_priority(cards[0], cards[1], cards[2])
                    if next_priority > current_priority:
                        winner["weight"] = high_weight
                        winner["sequence"] = " ".join(c for c in cards)

        except (IndexError, KeyError) as e:
            sys.exit("INVALID INPUT")
        except Exception as e:
            sys.exit(e)
        i += 1

    print(winner["sequence"])

main()
