def main():
    student_list = []
    i = 0

    students_num = input()

    while i < students_num:
        std = (raw_input().split())
        std_info = (std[0], int(std[1]), int(std[2]))
        # Check Age
        if (std_info[1] > 5) and (std_info[1] < 16):
            student_list.append(std_info)
        i += 1

    students_num = len(student_list)
    if students_num is 0:
        print "None of the students satisfy Age condition!!!"
        return

    student_list = sorted(student_list, key=lambda x: (x[0], x[1], x[2]))

    for s in student_list:
        print s[2],
        #print s


if __name__ == '__main__':
    main()
