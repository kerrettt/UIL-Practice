'''
   :platform : Windows, Linux

    ..moduleauthor :: Suraj S

    Prints the number of blocks with highest value in the Matrix
'''
test_cases = int(raw_input())
N=test_cases
# Set global minimum to the highest possible value
min_x = min_y = 1000000
while test_cases > 0:
    data = map(int, raw_input().split())
    # Compare with the Global minimum & replace it if the new entry is minimum
    min_x = min(data[0], min_x)
    min_y = min(data[1], min_y)
    test_cases -= 1
# BOOM !!! ITS DAMN EASY, JUST MULTIPLY YOUR MINIMUM VALUES
print N,min_x * min_y
