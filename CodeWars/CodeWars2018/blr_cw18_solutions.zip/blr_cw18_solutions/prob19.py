#!/usr/bin/python
# Author: karthik.r@hpe.com
# June 18th 2018
# Version 0.3

import copy
import math
import random
import string


DEBUG = False
#DEBUG = True
class PuzzlePiece:
    def __init__(self, value):
        #print value[:-4]
        self.number = int(value[:-4])
        self.top = value[-4]
        self.left = value[-3]
        self.bottom = value[-2]
        self.right = value[-1]
        self.value = value

    def is_corner(self):
        count = 0
        if self.left == 'x':
            count += 1
        if self.right == 'x':
            count += 1
        if self.bottom == 'x':
            count += 1
        if self.top == 'x':
            count += 1
        if count>1:
            return True
        else:
            return False

    def __str__(self):
        return self.value

    def __repr__(self):
        return self.value


def complements(side):
    if side == 'x':
        return None
    elif side.isupper():
        return side.lower()
    else:
        return side.upper()


def print_matrix(matrix):
    for row in matrix:
        print row


class Puzzle:

    def __init__(self, pieces):
        self.pieces = copy.deepcopy(pieces)
        self.rows = self.get_rows()
        self.cols = self.get_cols()
        self.solution = [[None for _ in range(self.cols)] for _ in range(self.rows)]
        #self.print_solution()
        self.solved = self.solve(self.solution, 0, 0, pieces)

    @staticmethod
    def prioritize_pieces(pieces, top, left, bottom=None, right=None):
        possible_pieces = filter(lambda piece: piece.top == top, pieces)
        left_pieces = filter(lambda piece: piece.left == left, possible_pieces)
        possible_pieces = left_pieces
        if bottom is not None:
            bottom_pieces = filter(lambda piece: piece.bottom == bottom, possible_pieces)
            possible_pieces = bottom_pieces
        if right is not None:
            right_pieces = filter(lambda piece: piece.right == right, possible_pieces)
            possible_pieces = right_pieces
        others = [piece for piece in pieces if piece not in possible_pieces]
        return  (possible_pieces, others)

    def print_solution(self):
        print_matrix(self.solution)
        
    def print_codewars_output(self):
        out_str = ""
        if self.solved:
            for row in self.solution:
                for piece in row:
                    out_str += '{0} '.format(piece.number)
                out_str += "\n"
        
        print out_str

    def get_rows(self):
        count = 0
        for piece in self.pieces:
            if piece.left == 'x':
                count += 1
        return count
        
    def get_cols(self):
        count = 0
        for piece in self.pieces:
            if piece.top == 'x':
                count += 1
        return count

    @staticmethod
    def piece_expects(puzzle_obj, row_index, col_index, puzzle_rows, puzzle_cols):
        """ Returns what this index in the puzzle object expects the top and left sides to be"""
        if row_index == 0:
            top = 'x'
        else:
            top = complements(puzzle_obj[row_index-1][col_index].bottom)
        if col_index == 0:
            left = 'x'
        else:
            left = complements(puzzle_obj[row_index][col_index-1].right)

        if puzzle_rows -1 == row_index:
            bottom = 'x'
        else:
            bottom = None

        if puzzle_cols -1 == col_index:
            right = 'x'
        else:
            right = None
        return (top,left, bottom, right)

    def solve(self, matrix, m, n, pieces):
        global DEBUG

        if DEBUG:
            print '*'*80
            print 'Solving %d %d' % (m,n)
            print "Incoming Matrix:"
            print_matrix(matrix)

        (_top, _left, _bottom, _right) = self.piece_expects(matrix, m, n, self.rows, self.cols)
        (candidates, others) = self.prioritize_pieces(pieces, _top, _left, _bottom, _right)
        for candidate in candidates:
            candidates2 = copy.deepcopy(candidates)
            others2 = copy.deepcopy(others)
            matrix2 = copy.deepcopy(matrix)
            if DEBUG:
                print "Checking:", m, n, "\nWith candidate:", candidate,\
                       "\nAll options", candidates, "\nothers", others
                print "Count of pieces left:", len(candidates + others)
            for candidate2 in candidates2:
                if candidate2.value == candidate.value:
                    candidates2.remove(candidate2)
                    break
            matrix[m][n] = candidate
            matrix2[m][n] = candidate2
            if n + 1 >= self.cols:
                if m + 1 >= self.rows:
                    #return self.solve(matrix, m, n, pieces2)  # reached the end.
                    return  True
                else:
                    next_m = m + 1
                    next_n = 0
            else:
                next_n = n + 1
                next_m = m
            if self.solve(matrix2, next_m, next_n, candidates2 + others2):
                #TODO: Why should we directly acess the base object variable ???
                self.solution[next_m][next_n] = matrix2[next_m][next_n]
                return  True
            else:
                #backtracking
                matrix[m][n] = None
            if DEBUG:
                print "Checking:", m, n,
                print "Candidate:", candidate, "Failed.. backtracking"
        return False


    def __str__(self):
        print "List of all pieces: {0}".format(self.pieces)
        for row in self.solution:
            print row        
        return ""

def read_input():
    num_pieces = raw_input()    
    #print num_pieces
    pieces = []
    for _ in range(int(num_pieces)):
        #pieces.append(raw_input().replace(" ", ""))
        pieces.append(PuzzlePiece(raw_input().replace(" ", "")))
    
    #print pieces
    return pieces
    
def main():
    test_input = read_input()
    codewars = Puzzle(test_input)
    if DEBUG:    
        print codewars
    codewars.print_codewars_output()


if __name__ == "__main__":
    main()
