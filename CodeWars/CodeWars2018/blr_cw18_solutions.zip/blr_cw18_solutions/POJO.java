import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Team building exercise at Taj Vivanta
 * @author Vaishnavi Mathavan
 * Copyright HPE @ 2018
 */

/**
 * Class that has getters and setters for class variables
 * Also does grouping of employees based on maximum group size
 */
public class POJO 
{

	int maxGrpSize;
	int formedGrpSize = -1;
	Map<Integer,ArrayList<Integer>> mgrReportMap = new LinkedHashMap<>();
	LinkedList<LinkedList<Integer>> alreadyClubList = new LinkedList<>();

	/**
	 * @param mgrReportMap
	 */
	public void setMgrReporteeMap(Map<Integer,ArrayList<Integer>> mgrReportMap)
	{
		this.mgrReportMap = mgrReportMap;
	}

	/**
	 * @param maxGrpSize
	 */
	public void setMaxGrpSize(int maxGrpSize)
	{
		this.maxGrpSize = maxGrpSize;
	}

	/**
	 * @param parent
	 * @return child list
	 */
	public ArrayList<Integer> getChildList(int parent)
	{
		return this.mgrReportMap.get(parent);
	}

	/**
	 * @param reportee
	 * @return Supervisor's id
	 */
	public Integer getSupervisor(int reportee)
	{
		for(Map.Entry<Integer, ArrayList<Integer>> mapEntry : this.mgrReportMap.entrySet())
		{
			if(mapEntry.getValue().contains(reportee))
				return mapEntry.getKey();
		}
		return 0;
	}

	/**
	 * Sets the current formed group size
	 * Group that has minimal groups
	 */
	public void setFormedGroupSize()
	{
		if(this.formedGrpSize == -1)
			this.formedGrpSize = alreadyClubList.size();
		else if(alreadyClubList.size() < this.formedGrpSize)
			this.formedGrpSize = alreadyClubList.size();
	}

	/**
	 * @return formed groups size
	 */
	public int getFormedGroupSize()
	{
		return this.formedGrpSize;
	}

	/**
	 * @return Clubbed list
	 */
	public LinkedList<LinkedList<Integer>> getFormedGroup()
	{
		return alreadyClubList;
	}

	/**
	 * Clear formed Groups
	 */
	public void clearFormedGroup()
	{
		alreadyClubList.clear();
	}

	/**
	 * Clear formed groups size
	 */
	public void clearFormedGroupSize()
	{
		this.formedGrpSize = -1;
	}

	/**
	 * Check whether already part of group
	 * @param eltToAdd
	 * @return whether part of group
	 */
	public boolean isPartOfGroup(int eltToAdd)
	{
		boolean isPart = false;
		if(alreadyClubList.size() == 0)
			return false;
		else
		{
			for(LinkedList<Integer> listEntry : alreadyClubList)
			{
				isPart = listEntry.contains(eltToAdd);
				if(isPart)
					return isPart;
			}
		}
		return isPart;
	}

	/**
	 * @param eltAdd
	 * @return current groups size
	 */
	public int getCurrentGroupSize(int eltAdd)
	{
		if(alreadyClubList.size() < 0)
			return 0;
		else
		{
			for(int i = 0; i < alreadyClubList.size(); i++)
			{
				if(alreadyClubList.get(i).contains(eltAdd))
				{
					return alreadyClubList.get(i).size();
				}
			}
		}
		return 0;
	}

	/**
	 * Method to add employees to respective groups based on hierarchy
	 * @param empId
	 * @param immMgr
	 */
	public void addEmpToGroup(int empId, int immMgr)
	{
		if(!isPartOfGroup(empId))
		{
			if(alreadyClubList.size() == 0)
			{
				addToClub(empId);
			}
			else  //its not the first entry
			{
				for(int i = 0; i < alreadyClubList.size(); i++)
				{
					if(!isPartOfGroup(empId))
					{
						//Check the entire already formed list for presence of immediate manager
						if(addReporteeWithMgrGroup(empId, immMgr) != -1)
							break;
						else
						{
							// If Emp id 1 was not prev added 
							//need to check if any of its reportees already part of the club
							//Add 1 to group which is not max grp size still
							if(empId == 1)
							{
								int grpToAdd = findGroupToAddMD(empId);
								if(grpToAdd != -1)
								{
									LinkedList<Integer> prevGroupEntry = alreadyClubList.get(grpToAdd);
									prevGroupEntry.add(empId);
									alreadyClubList.remove(alreadyClubList.get(grpToAdd));
									alreadyClubList.add(grpToAdd, prevGroupEntry);
								}
								else 
								{
									addToClub(empId);
								}
							}
							else if(mgrReportMap.get(empId).size() > 0)
							{
								addToClub(empId);
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Add reportees and managers in same group
	 * @param empId
	 * @param immMgr
	 * @return
	 */
	public int addReporteeWithMgrGroup(int empId, int immMgr)
	{
		int grpAddedTo = -1;
		boolean isSibbling = false;
		LinkedList<Integer> temp= new LinkedList<Integer>();
		temp.add(empId);

		for(int i = 0; i < alreadyClubList.size(); i++)
		{
			if(!isPartOfGroup(empId))
			{
				if(alreadyClubList.get(i).contains(immMgr))
				{
					LinkedList<Integer> prevGroupEntry = alreadyClubList.get(i);
					if(prevGroupEntry.size() < maxGrpSize && !prevGroupEntry.contains(empId))
					{
						if(prevGroupEntry.size() >= 2)
						{
							for(Integer entryInPrevGroup : prevGroupEntry)
							{
								if(getSupervisor(entryInPrevGroup) == getSupervisor(empId))
								{
									isSibbling = true;
									break;
								}
								else
									continue;
							}
							if(!isSibbling)
							{
								prevGroupEntry.add(empId);
								alreadyClubList.remove(alreadyClubList.get(i));
								alreadyClubList.add(i, prevGroupEntry);
								grpAddedTo = 1;
							}
							else
							{
								addToClub(empId);
								grpAddedTo = 2;
							}
						}
						else if(prevGroupEntry.size() < 2)
						{
							if(getSupervisor(empId) == prevGroupEntry.get(0))
							{
								prevGroupEntry.add(empId);
								alreadyClubList.remove(alreadyClubList.get(i));
								alreadyClubList.add(i, prevGroupEntry);
								grpAddedTo = 1;
							}
							else
							{
								addToClub(empId);
								grpAddedTo = 2;
							}
						}
					}
					else if(prevGroupEntry.size() == maxGrpSize && !alreadyClubList.contains(temp))
					{
						addToClub(empId);
						grpAddedTo = 2;
					}
				}
			}
		}
		return grpAddedTo;
	}

	/**
	 * Add employee to separate group
	 * @param empId
	 */
	private void addToClub(int empId)
	{
		LinkedList<Integer> tempList= new LinkedList<Integer>();
		tempList.add(empId);
		alreadyClubList.add(tempList);
	}

	/**
	 * Finds the group number wherein manager needs to be added
	 * @param empId
	 * @return group number wherein manager needs to be added
	 */
	public int findGroupToAddMD(int empId)
	{
		int groupNum = -1; 
		List<Integer> myReportees = mgrReportMap.get(empId);
		for(int m = 0; m < myReportees.size(); m++)
		{
			for(int n = 0;  n < alreadyClubList.size(); n++)
			{
				if(alreadyClubList.get(n).contains(myReportees.get(m)))
				{
					if(alreadyClubList.get(n).size() < maxGrpSize)
					{
						groupNum = alreadyClubList.indexOf(alreadyClubList.get(n));
						return groupNum;
					}
				}
			}
		}
		return groupNum;
	}
}
