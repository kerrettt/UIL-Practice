instructions = {
    "STR"		: 0X80,
    "STA"		: 0X50,
    "LDR"		: 0X60,
    "LDA"		: 0X70,
    "ADD"		: [0x20,0X40],
    "BASE"		: 0X10,
    "IF"		: 0X90,
    "GOTO"		: 0XA0
}
registers = {
    "R1"	: 0X00,
    "R2"	: 0X01,
    "R3"	: 0X02
}


def isRegister(value):
    return value in registers


Lines = [input().split(" ") for x in range(int(input()))]
byteCode = []
labels = {}
baseAddr = 0
for i in range(len(Lines)):
    line = Lines[i]
    if line[0] == "BASE":
        baseAddr = int(line[1], 16)
    elif line[0] == "LABEL":
        labels[line[1]] = i

for i in range(len(Lines)):
    line = Lines[i]
    if len(line) == 2:
        ins = line[0]
        value = line[1]
        if ins == "BASE":
            byteCode.append(instructions[ins])
            byteCode.append(int(value, 16))

        elif ins == "GOTO":
            value = labels[value]
            byteCode.append(instructions[ins])
            byteCode.append(value)

    elif len(line) == 3:
        ins = line[0]
        op1 = line[1]
        op2 = line[2]
        if ins == "ADD":
            if isRegister(op1) and isRegister(op2):
                Opcode = instructions[ins][1]
            else:
                Opcode = instructions[ins][0]
        else:
            Opcode = instructions[ins]
        if isRegister(op1):
            Opcode = Opcode + registers[op1]
        byteCode.append(Opcode)

        if not isRegister(op1):
            byteCode.append(int(op1, 16) + baseAddr)
        if isRegister(op2):
            byteCode.append(registers[op2])
        else:
            byteCode.append(int(op2, 16))
for val in byteCode:
    print("%.2X" % (val), end=" ")
	#print(int(val,16),end=" ")