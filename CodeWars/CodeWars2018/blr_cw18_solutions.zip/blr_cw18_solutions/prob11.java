

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;



public class prob11 {

	public static int mazeRow;
	public static int mazColunm;
	public static int gabbarX;
	public static int gabbarY;
	public static int thakurX;
	public static int thakurY;
	public static boolean isSuccess = false;
	public static int brickCount =0;
	public static int noGranades;
	public static boolean Success = false;
	static int numberofpath = 0;
	static int brick = 0;
	public static Map<Integer, Integer> map = new HashMap<Integer, Integer>();
	public static Map<Integer, BrickIndex> brickposmap = new HashMap<Integer, BrickIndex>();
	public static ArrayList<Integer> brickpos = new ArrayList<>();



	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		//System.out.println("Enter the size of the maze :\n");
		mazeRow = sc.nextInt();
		mazColunm = sc.nextInt();
		//System.out.println("Enter the number of Brick walls and Positions :");
		int brickNumber = sc.nextInt();
		int[] brickPositions = new int[brickNumber];
		for(int i = 0;i< brickNumber;i++){
			brickPositions[i] = sc.nextInt();
		}
		//System.out.println("Enter the number of Iron walls and Positions :");
		int IronWallNo = sc.nextInt();
		int[] ironWallPos = new int[IronWallNo];
		for(int i = 0;i< IronWallNo;i++){
			ironWallPos[i] = sc.nextInt();
		}
		//System.out.println("Enter the initial location of Gabbar and Thaku :");
		int gabbarPos = sc.nextInt();
		int thakurPos = sc.nextInt();
		//System.out.println("Enter the inumber of grenades :");
		noGranades =sc.nextInt();
		sc.close();

		//Copying the input values to a [m][n] matrix
		int [][]  maze = new int[mazeRow][mazColunm];
		int count = 0;
		boolean flag = false;
		int brickCount = 0;
		for(int i = 0;i<mazeRow;i++){

			if(i%2 ==0){
				for(int j=0;j<mazColunm;j++){
					count++;	
					for(int b= 0;b<brickNumber;b++){
						if(count ==brickPositions[b]){
							maze[i][j]=2;
							brickposmap.put(++brickCount,new BrickIndex(i,j));
							flag = true;
							break;
						}
					}
					for(int I= 0;I<IronWallNo;I++){
						if(count ==ironWallPos[I]){
							maze[i][j]=-1;
							flag = true;
							break;
						}
					}

					if(count ==gabbarPos){

						gabbarX =i;
						gabbarY=j;
						flag = true;
					}
					if(count ==thakurPos){
						maze[i][j]=9;
						thakurX=i;
						thakurY =j;
						flag = true;

					}

					if(!flag)
						maze[i][j]=0;

				}
			}
			else{
				for(int j=mazColunm - 1;j>=0;j--){
					count++;	
					for(int b= 0;b<brickNumber;b++){
						if(count ==brickPositions[b]){
							maze[i][j]=2;
							brickposmap.put(++brickCount,new BrickIndex(i,j));
							flag = true;
							break;
						}
					}
					for(int I= 0;I<IronWallNo;I++){
						if(count ==ironWallPos[I]){
							maze[i][j]=-1;
							flag = true;
							break;
						}
					}

					if(count ==gabbarPos){

						gabbarX =i;
						gabbarY=j;
						flag = true;
					}
					if(count ==thakurPos){
						maze[i][j]=9;
						thakurX=i;
						thakurY =j;
						flag = true;

					}

					if(!flag)
						maze[i][j]=0;

				}	
			}
		}

		int[][] mazecopy = new int [mazeRow+2][mazColunm+2];

		for (int [] row: mazecopy)
			Arrays.fill(row, 1);


		for(int i = 0;i<mazeRow+2;i++){
			for(int j=0;j<mazColunm+2;j++){
				if(i<mazeRow && j<mazColunm)
					mazecopy[i+1][j+1]=maze[i][j];
			}
		}

		System.out.println(Arrays.deepToString(maze).replace("], ", "]\n").replace("[[", "[").replace("]]", "]"));
		List<Integer> path = new ArrayList<>();
		//Calling the method to check is any free path is available
		searchpath(mazecopy, gabbarX+1, gabbarY+1, path);
		//System.out.println(path);
		//System.out.println(brickposmap);
		if(isSuccess){
			System.out.println(noGranades +" YEH HAATH MUJHE DEDE THAKUR!!!");

		}else{
			//Finding all the possible path for the given maze
			prob11 escape = new prob11();			
			escape.pathsFrom(gabbarX, gabbarY, maze);
			System.out.println(map);
			int[] grandesleft = new int[10];
			int gcount =0;
			for(Map.Entry<Integer, Integer> data :map.entrySet()){

				if(data.getValue() <= noGranades && data.getKey()<10 &&data.getValue()>0 ){

					grandesleft[gcount++] = noGranades -data.getValue();

					Success =true;
				}
			}
			if(Success){
				System.out.println(grandesLeft(grandesleft)+ " YEH HAATH MUJHE DEDE THAKUR!!!");	
			}
			else{
				System.out.println("BACH GAYA THAKUR!!!");
			}
		}

	}


	/**
	 * Method to find if any free path is there and return success if present
	 * @param maze
	 * @param x
	 * @param y
	 * @param path
	 * @return
	 */

	public static boolean searchpath(int maze[][], int x , int y, List<Integer> path){

		if(maze[y][x]==9){

			path.add(x);
			path.add(y);
			isSuccess =true;
			return true;
		}

		if(maze[y][x]==0){

			maze[y][x] =2;
			int dx =-1;
			int dy = 0;
			if(searchpath(maze, x+ dx, y+dy, path)){
				path.add(x);
				path.add(y);
				return true;
			}

			dx =1;
			dy = 0;
			if(searchpath(maze, x+ dx, y+dy, path)){
				path.add(x);
				path.add(y);
				return true;
			}
			dx =0;
			dy = -1;
			if(searchpath(maze, x+ dx, y+dy, path)){
				path.add(x);
				path.add(y);
				return true;
			}

			dx =0;
			dy = 1;
			if(searchpath(maze, x+ dx, y+dy, path)){
				path.add(x);
				path.add(y);
				return true;
			}
		}

		return false;	
	}
	//Method to find the least number of genards
	public static int grandesLeft(int[] a){

		int temp; 
		int total = a.length;
		for (int i = 0; i < a.length; i++)   
		{  
			for (int j = i + 1; j < total; j++)   
			{  
				if (a[i] > a[j])   
				{  
					temp = a[i];  
					a[i] = a[j];  
					a[j] = temp;  
				}  
			}  
		}  
		return a[total-1];  	

	}

	/**
	 * Method to find the maximun number of possible paths
	 * @param i
	 * @param j
	 * @param a
	 * @return
	 */
	public int pathsFrom(int i, int j, int[][] a)
	{
		if(!isInBounds(i,j) || a[i][j] == 1 || a[i][j] == -1)
		{
			return 0;
		}

		for(Map.Entry<Integer, BrickIndex> pos :brickposmap.entrySet()){
			if(pos.getValue().xpos == i && pos.getValue().ypos==j){
				brick++;
				break;
			}
		}
		if(i == thakurX && j == thakurY)
		{
			map.put(++numberofpath, brick);
			brick=0;
			return 1;
		}
		try
		{
			a[i][j] = 1;
			return pathsFrom(i+1,j,a) +
					pathsFrom(i-1,j,a) +
					pathsFrom(i,j+1,a) +
					pathsFrom(i,j-1,a);
		}
		finally
		{
			// Restore the state of the maze before returning
			a[i][j] = 0;
		}
	}

	private boolean isInBounds(int i, int j)
	{
		return i>=0 && j >=0 && i < mazeRow && j < mazColunm;
	}


}

class BrickIndex{

	int xpos;
	int ypos;

	public BrickIndex(int x, int y) {
		this.xpos =x;
		this.ypos=y;
	}
}
