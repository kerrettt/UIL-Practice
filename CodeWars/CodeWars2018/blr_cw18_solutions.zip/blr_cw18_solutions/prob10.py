#!/usr/bin/python
# Author: karthik.r@hpe.compile

import random
import argparse

def toggle(ball):
    if ball == 'W':
        return 'B'
    else:
        return 'W'
        
def toggle_pipe(pipe):
    new_pipe = ""
    for ball in pipe:        
        new_pipe = new_pipe + toggle(ball)
    return new_pipe        

def to_nontransparent(transparent):
    non_transaparent = ""
    while len(transparent):
        last_ball = transparent[0]    
        if len(transparent) >1:
            transparent = transparent[1:]
        else:
            transparent = ""
        if last_ball == 'B':
            non_transaparent = toggle_pipe(non_transaparent)
        non_transaparent = non_transaparent + last_ball
    return non_transaparent
    
def to_transparent(non_transaparent):
    transparent = ""    
    while len(non_transaparent):
        first_ball = non_transaparent[-1]
        if len(non_transaparent) >1:
            non_transaparent = non_transaparent[:-1]
        else:
            non_transaparent = ""
        transparent = first_ball + transparent
        if first_ball == 'B':
            non_transaparent = toggle_pipe(non_transaparent)        
    return transparent
        
def cli():
    parser = argparse.ArgumentParser(description='Solve/Generate the piston problem.')
    parser.add_argument('-n', '--number', type=int, help='Number of balls in the piston')
    parser.add_argument('-t', '--transparent', type=str, help='Balls in transparent')
    parser.add_argument('-o', '--opaque', type=str, help='Balls in opaque')
                        
    args = parser.parse_args()
    if args.number:
        print gen_pipe(args.number)
    elif args.transparent:
        print "{0} was input in transparent {1} is output in opaque".format(args.transparent, 
                                                                            to_nontransparent(args.transparent))
    elif args.opaque:
        print to_transparent(args.opaque)
        print "{0} was input in opaque {1} is output in transparent".format(args.opaque, 
                                                                            to_transparent(args.opaque))
    else:
        pipe = raw_input()
        print to_nontransparent(pipe)
    return

def gen_pipe(number):    
    ball_type = ['B', 'W']
    pipe = ""
    for _ in range(number):
        pipe = pipe + random.choice(ball_type)        
        
    return pipe
        
def testing():
    pipe = gen_pipe(20)
    non_transaparent = to_nontransparent(pipe) 
    transparent = to_transparent(non_transaparent)
    print "Input transparent ", pipe
    print "Output non_transparent ", non_transaparent
    print "Output transparent ", transparent
    assert pipe == transparent
    
if __name__ == '__main__':
    cli()
    #testing()
    
    
  