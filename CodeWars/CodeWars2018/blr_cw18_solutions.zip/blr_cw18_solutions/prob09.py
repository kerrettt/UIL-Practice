import math
n = int(input())
if n <= 0:
    print ("Invalid input")
    exit(1)
angle = float(360) / n
tanValue = math.tan(math.radians(angle / 2))
perpend = 0.5 / tanValue
base = 1
print ("%.2f" % (n * 0.5 * perpend * base))
