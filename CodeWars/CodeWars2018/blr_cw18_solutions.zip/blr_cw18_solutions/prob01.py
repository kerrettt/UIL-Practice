import sys

def main():
    line = sys.stdin.readline()
    input = line.split(' ')
    interest = (int(input[0]) * int(input[1]) * int(input[2])) / 100
    print("{0:.2f}".format(interest))

if __name__ == '__main__':
    main()