import sys
size = int(input())
mines  = int(input())
coordinate = []
for i in range(mines):
	coordinates_combined  = input()
	coordinates_combined = coordinates_combined.split(" ")
	x = int(coordinates_combined[0])	
	y = int(coordinates_combined[1])	
	coordinate.append((x,y))
path = str(input())
direction = list(path)
x = y = 0
if (x,y) in coordinate:
	print("Dead")
	sys.exit()	
for i in direction:
	if i == 'R':
		y = y+1
	elif i == 'L':
		y = y -1
	elif i == 'U':
		x = x-1
	elif i == 'D':
		x = x+1
	if(x < 0 or y < 0 or x >= size or y >= size):
		print("INVALID")
		sys.exit()
	if (x,y) in coordinate:
		print("DEAD")
		sys.exit()
	else:
		continue
		
print("ALIVE")
	
	
 