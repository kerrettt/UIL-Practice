relations = [
    "2*arr[n-1]", # 2,4,6,8
    "3*arr[n-1]", # 3,9,27,81
    "arr[n-1]**3",  # 4,64,262144
    "arr[n-1]+3",  # 13,16,19,22,25
    "arr[n-1]+2",  # 14 16 18 20
    "2*arr[n-1]+2",  # 2,6,14,30,62
    "arr[n-1] + n*6",  # 0,6,18,36,60,90
    "arr[n-1] + 30 + 4*n",  # 108,142,180,222
    "arr[n-1] + 48 + 6*n",  # 216 270 330 396
    "arr[n-1] + 2*(n+1)",  # 2,6,12,20,30,42,56	
    "-3*arr[n-1]",  # 1,-3,9,-27,81
]
##"arr[n-1] + arr[n-2]",  # 1,1,2,3,5,8,13,21,34

def main():
    inputLine = input()
    vals = list(map(int,inputLine.split()))
    #print (vals)
    for relation in relations:
        if checkPattern(relation,vals):
            #print("Relation MAtched: {}".format(relation))
            print(getNextInTheSequence(relation,vals))
            break


def getNextInTheSequence(relation, arr):
    n = len(arr)
    val = eval(relation)
    return val

def checkPattern(relation, arr):
    i = 1
    matched = True
    #print("Relation: {}".format(relation))
    while i < len(arr):
         n = i
         val = eval(relation)
         #print(val)
         if val != arr[n]:
            #print ("false")
            return False
         i += 1
    return matched


if __name__ == '__main__':
    main()
