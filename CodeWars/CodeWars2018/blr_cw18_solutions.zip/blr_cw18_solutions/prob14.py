"""
Whats the cost of a newspaper advertisement?

A newspaper prints ads and charge their customer based on the number of words. For each word they charge x Rs. If the word is made bold then the cost increases by 30%. If a word is underlined the cost increases by 20%.
If a background color is used, then the cost doubles up. Note any word in the advertisement can be bold, underlined or have a background color.
The first line of input specifies the cost per word. The next line contains the ad text upto 500 words.
Any words specified between <b> and </b> is considered as bold. 
Any words specified between <u> and </u> is considered underlined.
Any words between <bg> and </bg> is considered to have different background color.
There can be any number of instances of <b>, <bg>, <u> and program has to capture all matches.

Calculate the cost of the advertisement given the text.

Sample Input 1:
10
<bg>EAST Bangalore/Whitefield. Rs. 12,000/- per month.</bg> Beautiful 1BHK. Newly <u>renovated.</u> Walk-in pantry. Hot water included. No Fee. View pics at www.website.com. Call Agent 98564 78987.

Ans: 25 words, 5 words with bg, 1 word underlined.

25*10 + 5*10 + 1*2 = 302

Sample Input 2:
10
Required Accountant having experience of atleast 3-5 years, <u>well versed with <b>Tally</b>, accountancy & Taxation.</u> Interested candidates may send their resume to Interview between 11 AM to 5 PM on 23rd, 24th & 25th Nov 2017

36 words, 7 words underlined and 1 word bold

Ans: 36*10 + 7*2 + 1*3 = 377

"""

import re

cost_of_word=int(input())

if (cost_of_word <= 0):
    print ('Invalid input, exiting...')
    exit()

full_string=input()
#print (full_string)
words=full_string.split()
#print (words)
total_words = len(words)
#print (total_words)
total_cost = total_words * cost_of_word
#print (total_cost)


m = re.findall(r'<bg>(.*?)<\/bg>', full_string)
if m:
    #print (len(m))
    #print (m)
    for j in range(len(m)):
        subbg=m[j]
        #print (j, subbg)    
        total_bg = len(subbg.split())
        #print ("tbg:", total_bg)
        total_cost=total_cost + (total_bg * cost_of_word)

m = re.findall(r'<b>(.*?)<\/b>', full_string)
if m:
    #print (len(m))
    #print (m)
    for j in range(len(m)):
        subb=m[j]
        #print (j, subb)    
        total_b = len(subb.split())
        #print ("tb:", total_b)
        total_cost=total_cost + (total_b * cost_of_word * 0.30)

m = re.findall(r'<u>(.*?)<\/u>', full_string)
if m:
    #print (len(m))
    #print (m)
    for j in range(len(m)):
        subu=m[j]
        #print (j, subu)    
        total_u = len(subu.split())
        #print ("tu:", total_u)
        total_cost=total_cost + (total_u * cost_of_word * 0.20)

print (int(total_cost))

