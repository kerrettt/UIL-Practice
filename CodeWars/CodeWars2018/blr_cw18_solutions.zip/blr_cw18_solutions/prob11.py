import Queue

sizeX = None
sizeY = None
visited = []
irons = []
bricks = []

def find_neighbors(node):
    diff = sizeX*2-1;
    neighbors = []
    if (node - 1 > 0) and (node - 1 <= sizeX*sizeY) and ((node-1) not in visited) and ((node-1) not in irons) and ((node-1) not in neighbors):
        neighbors.append(node - 1)
    if (node + 1 > 0) and (node + 1 <= sizeX*sizeY) and ((node+1) not in visited) and ((node+1) not in irons) and ((node+1) not in neighbors):
        neighbors.append(node + 1)
    if (node%sizeX !=0) and (node + diff - 2*(node%sizeX-1) <= sizeX*sizeY) and (node + diff - 2*(node%sizeX-1) > 0) and (node + (diff - 2*(node%sizeX-1)) not in visited) and (node + diff - 2*(node%sizeX-1) not in irons) and ((node + diff - 2*(node%sizeX-1)) not in neighbors):
        neighbors.append(node + diff - 2*(node%sizeX-1))
    if (node%sizeX !=0) and ((node - (2*(node%sizeX - 1) + 1)) > 0) and ((node - (2*(node%sizeX-1) + 1)) <= sizeX*sizeY) and ((node - (2*(node%sizeX-1) + 1)) not in visited) and ((node - (2*(node%sizeX - 1) + 1)) not in irons) and ((node - (2*(node%sizeX-1) + 1)) not in neighbors):
        neighbors.append(node - (2*(node%sizeX - 1) + 1))
    return neighbors


class Pair(object):
    def __init__(self, first, second):
        self.first = first
        self.second = second
        return

    def __cmp__(self, other):
        return cmp(self.second, other.second)

def main():
    global irons, bricks, sizeX, sizeY, visited
    thakur = None
    bombs = None
    dist = {}
    INFINITE = 100000000

    sizeY, sizeX = raw_input().split()
    sizeX, sizeY = int(sizeX), int(sizeY)
    bricks = raw_input().split()
    bricks = bricks[1:]
    bricks = [int(i) for i in bricks]

    irons = raw_input().split()
    irons = irons[1:]
    irons = [int(i) for i in irons]

    gabbar, thakur = raw_input().split()
    gabbar, thakur = int(gabbar), int(thakur)
    bombs = int(input())

    for i in range(1, sizeX*sizeY + 1):
        dist[i] = INFINITE
    dist[gabbar] = 0

    touched = {}

    priority_queue = Queue.PriorityQueue()

    priority_queue.put(Pair(gabbar, 0))

    while not priority_queue.empty():
        top = priority_queue.get()
        node = top.first
        visited.append(node)
        curr_dist = top.second

        neighbors = find_neighbors(node)
        min_vector = []
        min_node = ()

        for n in neighbors:
            weight = 0
            if n in bricks:
                weight = 1
            if dist[node] + weight < dist[n]:
                dist[n] = dist[node] + weight

            if len(min_vector) == 0:
                min_node = [n, dist[n]]
                min_vector.append((n, dist[n]))
            else:
                if dist[n] < min_node[1]:
                    min_node = (n, dist[n])
                    min_vector = [min_node]
                elif dist[n] == min_node[1]:
                    min_vector.append((n, dist[n]))

        touched[node] = 1
        for val in min_vector:
            if val[0] not in touched:
                priority_queue.put(Pair(val[0], val[1]))

    answer = bombs - dist[thakur]
    if answer >= 0:
        print ("{} YEH HATH MUJHE DEDE THAKUR!!!".format(answer))
    else:
        print ("BACH GAYA THAKUR!!!")
    return

main()
