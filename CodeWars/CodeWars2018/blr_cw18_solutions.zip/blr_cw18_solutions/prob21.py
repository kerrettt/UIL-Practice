import re
import sys

if __name__ == "__main__":
	No = int(input())
	String = []
	for k in range(0,No):
		String.append(input())
		list_String = list(String[k])
		Multiplier = 1
		New_Multiplier = []
		Bracket_Multiplier = 1
		Hydrogen_Multiplier = 1
		Carbon_Multiplier = 1
		Carbon = 0
		Hydrogen = 0
		open = 0
		close = 0
		INVALID = None
		for i in range (len(list_String) - 1,-1 , -1):
			if(list_String[i] == 'C'):
				Carbon = Carbon + 1*Carbon_Multiplier*Multiplier
				Carbon_Multiplier = 1
			if(list_String[i] == 'H'):
				Hydrogen = Hydrogen + 1*Hydrogen_Multiplier*Multiplier
				Hydrogen_Multiplier = 1
			if(list_String[i].isdigit()):
				if(list_String[i-1] == 'C'):
					Carbon_Multiplier = int(list_String[i])
				elif(list_String[i-1] == 'H'):
					Hydrogen_Multiplier = int(list_String[i])
				elif(list_String[i-1] == ')'):
					Multiplier = Multiplier*int(list_String[i])
					New_Multiplier.append(int(list_String[i]))

			if(list_String[i] == ')'):
				close = close + 1
				continue
			if(list_String[i] == '('):
				
				open = open + 1
				if(open > close):
					INVALID = True
					break
				try:
					Multiplier = int(Multiplier/New_Multiplier.pop())
				except:
					continue

			
			
					
		if(open == close and INVALID == None):	
			print(Carbon,Hydrogen)
		else:
			print("INVALID")
				
					
				
			