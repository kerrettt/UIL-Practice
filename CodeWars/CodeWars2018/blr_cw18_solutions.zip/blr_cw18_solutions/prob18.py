import sys
house_number = int(input())
tiles = (house_number*house_number) + (house_number*(house_number+1))/2
print(int(tiles))