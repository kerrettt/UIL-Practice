import java.io.FileInputStream;//required for I/O from file
import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
/**
 * PROBLEM: Phone Passcode Cracking
 * DIFFICULTY LEVEL: HIGH (This problem is deceptively difficult to account for all edge cases, reversing the logic and covering all possible ways to extract a passcode possibility from the given data and rules involves looking at the algorithm in more than one way, else edge cases will be missed)
 * ESTIMATED COMPLETION TIME NEEDED: 25-40 minutes (assuming a team of 3-4 with access to all standard documentation for their chosen language)
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2018-11-30
 * WHAT IT TESTS: 
 * 	1.) Ability to use substrings and account for index range errors
 * 	2.) Ability to map data in sets according to an algorithm
 * 	3.) Ability to parse Integers as Strings, and vice versa
 * 	4.) Ability to work with sets of data, including merging sets, and comparing set members
 * 	5.) Ability to apply casts to numbers and to format strings as needed 
 * 	6.) Ability to work with math concepts in programming such as powers and square roots
 * 	7.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms. 
 * PROBLEM DESCRIPTION:
 * Your friend has bet you $20 that you cannot figure out their 4-digit phone passcode given 3 guesses. Using the smudges left on their screen over the numbers, and your knowledge of your friend's passcode rules, try to figure out their passcode.
 * 
 * Your friend always chooses a passcode where the first 2 digits (as a 2-digit number) are the square of the second 2 digits (as a 2-digit number).
 * 
 * ## Input
 * The dataset represents a phone passcode input screen:  
 * 
 * 	123  
 * 	456  
 * 	789  
 * 	X0X  
 * 	 
 * The dataset will be marked with C or U.  
 * C = clearly a number in the passcode.  
 * U = unclear, possibly used in the passcode.  
 * If a location is a digit or an X, then it isn't in the passcode.
 * 
 * ## EXAMPLE INPUT:
 * 	1C3  
 * 	4U6  
 * 	789  
 * 	XCX  
 * For this input, 2 and 0 are definitely used. 5 might be. No other digits are in the passcode.
 * 
 * ## Output
 * If you only find one possible combination of digits which could be the passcode, output:  
 *     CODE IS: ####
 * 
 * If two or three possible passcodes are found, output each on a new line as:  
 * 	POSSIBLE MATCH: ####  
 * 	POSSIBLE MATCH: ####  
 * 	POSSIBLE MATCH: ####  (if 3 codes are found, output 3 lines)
 * 
 * If four or more possible passcodes are found, output:  
 * 	WILL NOT WIN BET
 * 
 * If no possible passcodes exist, output:  
 * 	COULD NOT DETERMINE CODE
 * 
 * ### EXAMPLE OUTPUT:
 * 	CODE IS: 2505
 */
public class prob20 {
	/* SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA: ANSWERS
	 * -----------------------------------------------------------------------------------------
	 * 1: Basic implementation test
	 * 2: Tests small square, where both have zeros 
	 * 3: Tests correct detection of multiple possible answers
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA: ANSWERS
	 * -----------------------------------------------------------------------------------------
	 * 1: No matching squares with given information
	 * 2: Tests special square of zero, no unclear inputs
	 * 3: Tests special square of 1 
	 * 4: Tests correctly identifying that too many possible answers from the data will mean more than 3 guesses needed
	 * 5: Tests extreme case all digits are available to test, with only 2 known digits
	 * 6: Tests catch of digits existing in multiple squares and roots
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * Solution was coded heavily using lists, but arrays could just as easily be used (that just requires keeping track of an index)
	 * 
	 * The solution only uses libraries found in the standard Java Developer Kit (JDK), no external modules or 3rd party libraries are used.*/
	public static void main(String[] args) {
		try
		{
			runP2_smudges();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	private static void runP2_smudges()
	{
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\Users\\mcadamsr\\Desktop\\CodeWars\\2019DifficultProblems\\P2In0.txt");
		
		int[] digitsMap = new int[] {1,2,3,4,5,6,7,8,9,0};
		List<Integer> C = new ArrayList<Integer>();
		List<Integer> U = new ArrayList<Integer>();
		int mapIndex = 0;
		//PROCESS THE DATA
		for(String line: lines)
		{
			for(int i=0; i<=2;i++)
			{
				String c = "";
				if (i==2)
				{
					c = line.substring(i);//read to end
				}
				else
				{
					c = line.substring(i,i+1);//read + 1 character
				}
				if(!c.equalsIgnoreCase("X"))
				{
					if(c.equalsIgnoreCase("C"))
					{
						C.add(digitsMap[mapIndex]);
					}
					else if(c.equalsIgnoreCase("U"))
					{
						U.add(digitsMap[mapIndex]);
					}
					mapIndex++;	
				}
			}
		}
		List<Integer> candidates = new ArrayList<Integer>(C);
		candidates.addAll(U);
		List<Integer> possiblePairs = new ArrayList<Integer>();
		//using string to int, and int to string casting throughout the parsing 
		//because that is a relatively simple way of testing for leading zeros, etc.
		for(Integer num: candidates)
		{
			for(Integer candidate: candidates)
			{
				String combination = ""+num+candidate;
				Integer joined = Integer.parseInt(combination);
				if (!possiblePairs.contains(joined))
				{
					possiblePairs.add(joined);
				}
			}
		}
		List<String> possibleFinal = new ArrayList<String>();
		for(int i=0;i<possiblePairs.size();i++)
		{
			int current =possiblePairs.get(i); 
			int square = current * current;
			double root = Math.sqrt(current);
			String _root = ""+root;
			boolean squareRootOK = false;
			if (_root.contains(".0") && _root.length() <=3)
			{
				//we are only interested in a square root if it is an integer.
				//So, while the Java Square Root function returns a double, we are checking 
				//for a whole number with a zero in the decimal 10th place, and a total 
				//length of 3 or less as a string. 3 was chosen because the total length of
				//roots one can get from a 2 digit number, will always be one when represented
				//as an integer. Largest integer square that can be expressed in 2 digits is 81
				//which is the square of 9. And 9 is a single digit number, so expressed as
				//a double it would be 9.0, so 3 max for this particular little test
				squareRootOK = true;
			}
			if (possiblePairs.contains((int)root) && squareRootOK)
			{	
				if (testPossible(C, current, (int)root) == C.size())
				{	
					String passcode = determinePasscode(current, (int)root);
					//add the possible solution code to the final list, as long as it hasn't already been added
					if (!possibleFinal.contains(passcode))
					{
						possibleFinal.add(passcode);
					}
				}
			}
			else if (possiblePairs.contains(square))
			{
				if (testPossible(C, current, square) == C.size())
				{
					String passcode = determinePasscode(current, square);	
					if (!possibleFinal.contains(passcode))
					{
						possibleFinal.add(passcode);
					}
				}
			}
		}
		//OUTPUT
		if (possibleFinal.size() == 0)
		{
			System.out.println("COULD NOT DETERMINE CODE");
		}
		else if (possibleFinal.size() == 1)
		{
			System.out.println("CODE IS: "+possibleFinal.get(0));
		}
		else if (possibleFinal.size() > 3)
		{
			System.out.println("WILL NOT WIN BET");
		}
		else
		{
			for (String s: possibleFinal)
			{
				System.out.println("POSSIBLE MATCH: "+s);
			}
		}
	}
	//the possible pairs contains the square root we've calculated, and the root is an integer
	//now test the possible code and make sure it uses all of the known digits
	private static int testPossible(final List<Integer> knownDigits, int current, int testing)
	{
		int foundKnown = 0;
		for(int known: knownDigits)
		{
			String testable1 = ""+current;
			if (testable1.length() < 2)
			{
				testable1 = "0"+testable1;
			}
			String testable2 = ""+testing;
			if (testable2.length() < 2)
			{
				testable2 = "0"+testable2;
			}
			if (
					(testable1.contains(""+known))
					||
					(testable2.contains(""+known))
				)
			{
				foundKnown++;
			}
		}
		return foundKnown;
	}
	//if the possible code uses all of the known digits, determine the 2 parts to the
	//the code, and order them in the string order of: SQUARE+ROOT
	private static String determinePasscode(int current, int testing)
	{
		String result = "";
		String part1 = ""+testing;
		if (testing < 10)
		{
			part1 = "0"+part1;//pad with zero to account for integer representation of numbers
		}
		String part2 = ""+current;
		if (current < 10)
		{
			part2 = "0"+current;//pad with zero to account for integer representation of numbers
		}
		result = part1+part2;//order is: squared value+original value	
		if (current > testing)
		{
			result = part2+part1;//flip the order if needed to keep squared value on left	
		}
		return result;
	}
	private static List<String> readFromFileInputByCommandLine()
	{
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
