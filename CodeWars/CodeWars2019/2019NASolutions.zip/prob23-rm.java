import java.io.FileInputStream;//required for I/O from file
import java.text.DecimalFormat;
import java.util.Scanner;//required for I/O from stdin
import java.time.LocalDate;//required for DateTime parsing
import java.time.format.DateTimeFormatter;//required for DateTime parsing
import java.time.temporal.ChronoUnit;//required for DateTime parsing
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
import java.util.Map;//required for Map<T, T> (Java's version of a generic Dictionary) 
import java.util.TreeMap;//required to generate a Map object which we can sort at instatiation time
import java.util.Set;//required to generate an object from the Map which can be iterated over
import java.util.Collections;//required to be able to set the Map object's sorting order
import java.util.Iterator;//required to generate the actual iterator which we will use to walk over the Mapped set
/**
 * PROBLEM: Scoring Social Media Posts
 * DIFFICULTY LEVEL: MEDIUM-HIGH (Students at a high school level can get stuck on keeping track of the data (with no in-built way provided to them), along with common "gotchas" such as divide by zero issues, math problems such as integer division (depending on the language used), sorting and ordering the data, and handling dates )
 * ESTIMATED COMPLETION TIME NEEDED: 20-35 minutes  
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615  
 * LAST MODIFIED: 2019-02-25
 * WHAT IT TESTS: 
 * 	1.) Ability to detect and handle divide by zero problems
 * 	2.) Ability to translate a complex algorithm into accurate code
 * 	3.) Ability to organize a set of data into an ordered list sorted in descending order (not easy depending on the language being used, and familiarity with the language)
 * 	4.) Ability to remove an item from a data set
 * 	5.) Ability to figure out a way to track items in a data set and link the extrapolated data from the set back to the set itself
 * 	6.) Ability to handle dates, and how to also calculate time period lengths between dates (this by itself will be problematic in languages without built-in (easy to use) date handling libraries, such as ANSI C)
 * 	7.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms. 
 * PROBLEM DESCRIPTION: 
 * Given a set of posts for your social media feed, sort and display the posts according to a scoring system.
 * Each pipe delimited line of data will consist of:
 *
 * A post title
 * Poster Name
 * Post likes
 * Post dislikes
 * Poster's follower count (warning, this can be a huge number)
 * If you are following them
 * If you have blocked the poster
 * Posting date (in format: yyyy-MM-dd)
 * Poster's join Date
 * Total posts from poster
 *
 * Calculate an "importance" score for the posts (the larger the number, the higher the "importance") based on the following formula:
 *
 * Starting score = 10,000 points.
 * If the poster has a million followers (or more), add 10,000 points.
 * If the poster has less than one hundred followers, subtract 5,000 points.
 * Divide the score by the total likes for the post subtracting the total dislikes, if the likes do not equal the dislikes, else divide by 100.
 * If you are following the poster, add 5,000 points.
 * If the post is a week or less old, add 500 points, else if the post is more than 2 weeks old, subtract 100 points.
 * Add the poster's total number of posts, and the total number of weeks since the poster joined.
 * Remove the post from the list entirely if you've blocked the poster.
 *
 * You are safe to assume that each data line will be complete and not missing any data.
 * Once the scores are calculated for each post, sort the list in descending order of their "importance" score
 *
 * Finally, output the list in the format:
 * (importance score) Post title, by: Poster Name [Posting date (in format: yyyy-MM-dd)]
 * Example:
 * (22314.9) An example post, by Jane Smith [2019-03-04]
 *
 * If the scoring process removes all posts from the list, output instead:
 * You are blocking all (##) posters in your feed, where ## is the number of unique poster names (CaSe sEnSiTiVe) found in the list.
 */
public class prob23 {
	/* SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) tests celebrity following aspect of algorithm, no blocks, lots of special characters, and dates and number ranges across a wide area
	 * 2.) tests blocking 1 poster
	 * 3.) tests old date handling
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) tests blocking all posters
	 * 2.) tests blocking 1 poster, and having negative likes as divisor
	 * 3.) tests dates in the future along with huge follower count (larger than an int)
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * The provided solution uses another class both to hold the post data, and also to calculate the post's score.
	 * The solution (obviously) didn't need to use another class in order to work, that was just a stylistic
	 * and brevity of typing choice on my part.
	 * 
	 * The solution only uses libraries found in the standard Java Developer Kit (JDK), no external modules or 3rd party libraries are used.*/
	public static void main(String[] args) {
		try
		{
			runP5_SocialMedia();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	private static void runP5_SocialMedia()
	{
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\CodeWars2019\\probAH-Social-Media-Post-Scoring-McAdams\\probAH-judge-3-in.txt");
		
		List<String> uniquePosters = new ArrayList<String>();
		//COLLECT AND SCORE THE DATA
		//Java way to do a Dictionary, and to sort in descending order on the key, could do the same thing with a 2-dimensional array managed manually, but that takes way more time (that is is exactly what would be needed in C/C++ though)
		Map<Float, Integer> myMap = new TreeMap<Float, Integer>(Collections.reverseOrder());
		/*Float=score key, Integer=line hash.toString() value*/
		for (String line: lines)
		{
			SocialMediaPost post = new SocialMediaPost(line);
			if (!uniquePosters.contains(post.poster))
			{
				uniquePosters.add(post.poster);
			}
			if (!post.blocked)
			{
				//There are several ways to keep track of the posts.
				//An easier way to do this in a C/C++ environment (with no built in support for generating hash values of objects)
				//would be to create a 2 dimensional array to hold the inputs with an additional data field which would be a simple 
				//ID which is incremented by 1 for each new entry, then simply reference that ID to look it up again
				Integer lineHash = line.hashCode();
				//System.out.println(post.title+" has score: "+post.score()+", and hash="+lineHash);
				myMap.put(post.score(), lineHash);
			}
		}
		if (myMap.size() > 0)
		{
			//ITERATE OVER THE SCORED FINAL LIST
			//System.out.println(myMap);	
			Set<Float> setCodes = myMap.keySet();
			Iterator<Float> iterator = setCodes.iterator();
			while (iterator.hasNext())
			{
				//FOR EACH ITEM IN THE FINAL LIST, GET THE SCORE AND THE HASH VALUE OF THE ORIGINAL LINE
				//USE THE HASH VALUE TO FIND THE ORIGINAL LINE AND PARSE IT AGAIN SO WE CAN OUTPUT IT
				Float code = iterator.next();
				Integer hash = myMap.get(code);
				//System.out.println(code + " => " + hash);
				for (String line: lines)
				{
					//yes, it is possible to hash the lines when creating the list, but that adds complexity and time to the process, 
					//and the solution attempts to be simple to follow
					if(line.hashCode() == hash)
					{//using a class just to avoid duplicating lines of code, could easily do this without a second class
						SocialMediaPost post = new SocialMediaPost(line);
						DecimalFormat df = new DecimalFormat("0.0");
						System.out.println("("+df.format(post.score())+") "+ post.title+", by: "+post.poster +" ["+post.posted+"]");
					break;
					}
				}
			}
		}
		else
		{
			System.out.println("You are blocking all ("+uniquePosters.size()+") posters in your feed");
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
/**
 * CLASS: SocialMediaPost
 * AUTHOR: Robert McAdams, mcadams@hpe.com
 * LAST MODIFIED: 2018-11-30
 * PURPOSE: Simple data passing/holding class. Can be instantiated with the data line which will be parsed for all of its property values.
 * 			All properties are public. There is one utility method which is used to calculate the "score" for the data based on the
 * 			algorithm given in the problem description.
 * */
class SocialMediaPost{
	public SocialMediaPost()
	{
	}
	public SocialMediaPost(String input)
	{
		String[] parts = input.split("\\|");//pipe is interpreted as a regex here in Java to split every character, need to escape it to a literal
		title = parts[0];
		poster = parts[1];
		likes = Integer.parseInt(parts[2]);
		dislikes = Integer.parseInt(parts[3]);
		followers = Long.parseLong(parts[4]);
		following = Boolean.parseBoolean(parts[5]);
		blocked = Boolean.parseBoolean(parts[6]);
		posted = LocalDate.parse(parts[7], DateTimeFormatter.ISO_DATE);
		joined = LocalDate.parse(parts[8], DateTimeFormatter.ISO_DATE);
		posts = Integer.parseInt(parts[9]);
	}
	public String title ="";
	public String poster = "";
	public int likes = 0;
	public int dislikes = 0;
	public long followers = 0;
	public boolean following = false;
	public boolean blocked = false;
	public LocalDate posted = null;
	public LocalDate joined = null;
	public int posts = 0;
	public float score()
	{
		float score = 10000;
		if (this.followers > 1000000) {
			score+=10000;
		}
		else if (this.followers < 100) {
			score -=5000;
		}
		if ((this.likes-this.dislikes)!=0)
		{
			score = score/(this.likes-this.dislikes);
		}
		else {
			score = score/100;
		}
		if (this.following) {
			score +=5000;
		}
		LocalDate today = LocalDate.now();
		long days = ChronoUnit.DAYS.between(this.posted,today);
		if (days <= 7) {
			score += 500;
		}
		else if (days > 14) {
			score -= 100;
		}
		score += this.posts;
		long weeks = ChronoUnit.WEEKS.between(this.joined,today);
		score += weeks;
		return score;
	}
}
