import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 * PROBLEM: Superhero Fight
 * DIFFICULTY LEVEL: MEDIUM to MEDIUM-HIGH
 * ESTIMATED COMPLETION TIME NEEDED: 15-20 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-05
 * WHAT IT TESTS: 
 * 	1.) Ability to move back and forth between data sets and keep accurate track of "where" in the process one is
 * 	2.) Ability to apply mathematical conversions to numbers on the fly in a changing state array (or other data structure)
 * 	3.) Ability to flip logic to enumerate an "opposite" value from a current value (XOR, or similar concept -- can be brute forced, but shouldn't be)
 * 	4.) Ability to implement "business logic" in a way which allows for unknown inputs while still constraining the output to the rules.
 *  5.) Ability to implement logic for different labels on the same data (again, this can be brute forced, but if recognized, this will save the student a lot of time)  
 * 	6.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * Who would win in a fight, Hulk® or Superman®? Would the USS Enterprise® win against a Star Destroyer®? What about a Super Star Destroyer®?[1]
 * It's time to decide once and for all!
 * 
 * Your local comics and games shop is hosting a tournament this weekend, and they need a scoring system for their fantasy battle game.
 * Teams will be able to submit a 'fighter' from one of 2 categories:
 * 
 * 1.  Person/Entity
 * 2.  Vehicle/Ship
 * 
 * A person will be able to draw from the following attributes (via dice rolls):
 * 
 *   HP: Health (when a person's health reaches zero (or below), they lose the fight)
 *   ST: Strength (determines damage bonus (how hard they hit) -- if >8 & <14 +1 to damage rolls, if >=14 & < 18 +2 to damage, if >=18 +3 to damage rolls)
 *   DF: Defense (determines minimal roll to hit)
 *   LK: Luck (if >8 & <14 +1 to defense, if >=14 & < 18 +2 to defense, if >=18 +3 to defense)
 * 
 * A Vehicle/Ship will be able to draw from the following attributes (via dice rolls):
 * 
 *   SI: Structural Integrity (when reaches zero (or below), they lose the fight)
 *   MW: Main Weapon (determines damage bonus (how hard it hits with primary weapon) -- if >8 & <14 +1 to damage rolls, if >=14 & < 18 +2 to damage, if >=18 +3 to damage rolls)
 *   AM: Armor (determines minimal roll to hit)
 *   TK: Technology (if >8 & <14 +1 to armor, if >=14 & < 18 +2 to armor, if >=18 +3 to armor)
 * 
 * Turns alternate per opponent.
 * Opponent with lowest defense/armor goes first (in a tie, opponent 1 goes first).
 * 
 * Combat rules per turn:
 * A number between 1-20 will be sent as a simulated dice "roll" to determine "to hit"
 * Check "hit" score against defense/armor + bonuses of defender
 * 	if >= defense/armor, roll for damage
 * 	else, turn ends
 * Rolling for damage:
 * 	A number between 1-10 will be sent as a simulated dice "roll" for "damage"
 * 	add any bonuses
 * 	subtract from target's health/structural integrity
 * If health/structural reaches zero or less battle is over, and the opponent with the greater than zero 
 * health/structural integrity wins.
 * 
 * Your scoring program needs to prove that it can accurately handle the inputs of a live tournament, so 
 * before the tournament will accept your program (and pay you for it), they want to run it through an 
 * automated trial run. They will submit pre-determined "battles" into your program, with all dice 
 * rolls pre-determined. Your program simply needs to apply the rules to the "battle" and output the winner.	
 * 
 * ## Input
 * 	Opponent1:Hulk
 * 	HP:20
 * 	ST:20
 * 	DF:16
 * 	LK:10
 * 	Opponent2:Loki
 * 	HP:12
 * 	ST:13
 * 	DF:12
 * 	LK:20
 * 	Rolls:
 * 	ROUND:1
 * 	TOHIT:17
 * 	DAMAGE:10
 * 	TOHIT:8
 * 	ROUND:2
 * 	TOHIT:20
 * 	DAMAGE:8
 * 		
 * ## Output
 * 	Opponent 1: Hulk®
 * 	Start HP=20
 * 	Damage Bonus=+3
 * 	Defense Bonus=+1
 * 	Defense: 17 (base 16+1)
 * 
 * 	Opponent 2: Loki®
 * 	Start HP=12
 * 	Damage Bonus=+1
 * 	Defense Bonus=+3
 * 	Defense: 15 (base 12+3)
 * 
 * 	Loki® will strike first.
 * 
 *	Round 1:
 *	Loki rolls 17 vs. 17 =HIT!
 *	Loki damage roll=10+1(bonus)=11
 *	Hulk HP Now=9
 *	Hulk rolls 8 vs. 15 =miss
 *	Round 2:
 *	Loki rolls 20 vs. 17 =HIT!
 *	Loki damage roll=8+1(bonus)=9
 *	Hulk HP Now=0
 *
 *	Loki HAS DEFEATED Hulk!!!
 * 
 * [1] All registered trademarks used without permission as fair-use examples.	
 * */
public class prob25 {
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Vehicle case with misses, exact hits, and high damage
	 * 2.) Longer case with more misses, more hits, and lower damage
	 * 3.) Extremely long case with lots of misses, many hits, and ranging damage
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Simple case, high damage, quick results
	 * 2.) Slug-fest, high damage back and forth with quick results
	 * 3.) Vehicle case, higher miss count, and higher hit count with medium damage
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * The solution provided is a quick-and-dirty solution done entirely with arrays and lists.
	 * This isn't the "correct" way to solve this problem, but it is a fast way, and it is the
	 * most obvious solution to the problem that a student might come up with.
	 * 
	 * (A much better solution that is extendable and maintainable would be to setup an 
	 * Model-View-Controller (MVC) implementation which separated the logic from the output
	 * and the data, and implemented classes for the data sets, with methods in those classes
	 * to determine the math involved with stats, etc. And the game logic would run in the 
	 * controller using objects of those classes -- but that takes far more time to implement
	 * than the solution provided here ^_-)
	 * 
	 * Possible sticking points for this problem will be setting up all of the initial inputs
	 * correctly. This is one of those types of problems where EVERYTHING will be wrong if the
	 * first decision made is wrong.
	 * 
	 * Another possible sticking point is how to apply the mathematical changes to the base numbers
	 * and how to move back and forth between the 2 opponents. The instinct to solve this with 
	 * a giant if/then/else block will not lead to a good solution, as the number of actions
	 * presented to their simulation of a game will be unknown and (effectively) unbounded.
	 * 
	 * Everything else is fairly straight forward. Simply setup the game rules, then run the
	 * actions through the game rules to generate the required output.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run_probAV();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results.
	 * */
	private static void run_probAV() {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\CodeWars2019\\probAV-Superhero-Fighters-McAdams\\prob-student-3-in.txt");
		List<String> actions =new ArrayList<String>();
		//PROCESS THE DATA
		String FighterName1 = "";
		int Fighter1HP = -1;
		int Fighter1ST = -1;
		int Fighter1DF = -1;
		int Fighter1LK = -1;
		int Fighter1DM = -1;
		int Fighter1_BonusDF = 0;
		String FighterName2 = "";
		int Fighter2HP = -1;
		int Fighter2ST = -1;
		int Fighter2DF = -1;
		int Fighter2LK = -1;
		int Fighter2DM = -1;
		int Fighter2_BonusDF = 0;
		int opponents=0;
		boolean rollsEncountered = false;
		for (String line:lines){
			String[] tmp = line.split(":");
			if (line.trim().equalsIgnoreCase("Rolls:")){
				rollsEncountered = true;
			}
			else if(rollsEncountered){
				actions.add(line);
			}
			else if (line.indexOf("Opponent") >= 0){
				opponents++;
				if (opponents==1){
					FighterName1 = tmp[1];
				}
				else{
					FighterName2 = tmp[1];
				}
			}
			else if (line.indexOf("HP:") >= 0 ||line.indexOf("SI:") >= 0){
				if (opponents==1){
					Fighter1HP = Integer.parseInt(tmp[1]);
				}
				else{
					Fighter2HP = Integer.parseInt(tmp[1]);
				}
			}
			else if (line.indexOf("ST:") >= 0 || line.indexOf("MW:") >= 0){
				if (opponents==1){
					Fighter1ST = Integer.parseInt(tmp[1]);
					if (Fighter1ST >= 18){
						Fighter1DM = 3;
					}
					else if (Fighter1ST >= 14){
						Fighter1DM = 2;
					}
					else if (Fighter1ST >= 9){
						Fighter1DM = 1;
					}
				}
				else{
					Fighter2ST = Integer.parseInt(tmp[1]);
					if (Fighter2ST >= 18){
						Fighter2DM = 3;
					}
					else if (Fighter2ST >= 14){
						Fighter2DM = 2;
					}
					else if (Fighter2ST >= 9){
						Fighter2DM = 1;
					}
				}
			}
			else if (line.indexOf("DF:") >= 0||line.indexOf("AM:") >= 0){
				if (opponents==1){
					Fighter1DF = Integer.parseInt(tmp[1]);
				}
				else{
					Fighter2DF = Integer.parseInt(tmp[1]);
				}
			}
			else if (line.indexOf("LK:") >= 0||line.indexOf("TK:") >= 0){
				if (opponents==1){
					Fighter1LK = Integer.parseInt(tmp[1]);
					if (Fighter1LK >= 18){
						Fighter1_BonusDF = 3;
					}
					else if (Fighter1LK >= 14){
						Fighter1_BonusDF= 2;
					}
					else if (Fighter1LK >= 9){
						Fighter1_BonusDF= 1;
					}
				}
				else{
					Fighter2LK = Integer.parseInt(tmp[1]);
					if (Fighter2LK >= 18){
						Fighter2_BonusDF= 3;
					}
					else if (Fighter2LK >= 14){
						Fighter2_BonusDF= 2;
					}
					else if (Fighter2LK >= 9){
						Fighter2_BonusDF= 1;
					}
				}
			}
		}
		//load into array depending on which will go first
		int[] fighters = new int[6];
		String[] names = new String[2];
		if (Fighter2DF < Fighter1DF){
			names[0] = FighterName2;
			names[1] = FighterName1;
			fighters[0]=Fighter2HP;
			fighters[1]=Fighter1HP;
			fighters[2]=Fighter2DF+Fighter2_BonusDF;
			fighters[3]=Fighter1DF+Fighter1_BonusDF;
			fighters[4]=Fighter2DM;
			fighters[5]=Fighter1DM;
		}
		else{//either fighter1's DF is lower, or there is a tie, either way, fighter 1 goes first
			names[0] = FighterName1;
			names[1] = FighterName2;
			fighters[0]=Fighter1HP;
			fighters[1]=Fighter2HP;
			fighters[2]=Fighter1DF+Fighter1_BonusDF;
			fighters[3]=Fighter2DF+Fighter2_BonusDF;
			fighters[4]=Fighter1DM;
			fighters[5]=Fighter2DM;
		}
		System.out.println("Opponent 1: "+FighterName1);
		System.out.println("Start HP="+Fighter1HP);
		System.out.println("Damage Bonus=+"+Fighter1DM);
		System.out.println("Defense Bonus=+"+Fighter1_BonusDF);
		System.out.println("Defense: "+(Fighter1DF+Fighter1_BonusDF)+" (base "+Fighter1DF+"+"+Fighter1_BonusDF+")");
		System.out.println("");
		System.out.println("Opponent 2: "+FighterName2);
		System.out.println("Start HP="+Fighter2HP);
		System.out.println("Damage Bonus=+"+Fighter2DM);
		System.out.println("Defense Bonus=+"+Fighter2_BonusDF);
		System.out.println("Defense: "+(Fighter2DF+Fighter2_BonusDF)+" (base "+Fighter2DF+"+"+Fighter2_BonusDF+")");
		System.out.println("");
		System.out.println(names[0]+" will strike first.");
		System.out.println("");
		int fighterIndex = 0;//keep track of whose turn it is
		for(String action:actions){
			String[] data = action.trim().split(":");
			if (data.length > 1)
			{
				if (data[0].equalsIgnoreCase("ROUND")){
					System.out.println("Round "+data[1]+":");
				}
				else if (data[0].equalsIgnoreCase("TOHIT")){
					//current fighter is rolling to hit against other fighter
					//need to compare roll to other fighter's defense
					int toHit = Integer.parseInt(data[1]);
					int def = fighters[2];//by default, assume the current fighter is fighter 2, so set defense to compare against to fighter 1's defense
					if (fighterIndex==0){//if current fighter is fighter 1, then set defense to compare against to fighter 2's
						def = fighters[3];
					}
					if (toHit >= def){
						System.out.println(names[fighterIndex] +" rolls "+toHit+" vs. "+def+" =HIT!");
					}
					else{
						System.out.println(names[fighterIndex] +" rolls "+toHit+" vs. "+def+" =miss");
						fighterIndex++;
						if (fighterIndex > 1){
							fighterIndex=0;
						}
					}
				}
				else if (data[0].equalsIgnoreCase("DAMAGE")){
					//current fighter is rolling damage against against other fighter
					int damage = Integer.parseInt(data[1]);
					int hp = fighters[0];//by default, assume the current fighter is fighter 2, so set defense to compare against to fighter 1's defense
					int bonus = fighters[5];
					if (fighterIndex==0){//if current fighter is fighter 1, then set defense to compare against to fighter 2's
						hp = fighters[1];
						bonus = fighters[4];//logic is flipped for damage bonus
					}
					hp -= damage;
					hp -= bonus;
					if (fighterIndex==0){
						fighters[1] = hp;
					}
					else{
						fighters[0] = hp;
					}
					System.out.println(names[fighterIndex] +" damage roll="+damage+"+"+bonus+"(bonus)="+(damage+bonus));
					System.out.println(names[(fighterIndex ^ 1)] +" HP Now="+hp);//using XOR operation to flip
					if (hp <=0){
						System.out.println("");
						System.out.println(names[fighterIndex] +" HAS DEFEATED "+names[(fighterIndex ^ 1)]+"!!!");
					}
					fighterIndex++;
					if (fighterIndex > 1){
						fighterIndex=0;
					}
				}
			}
			else
			{
				System.out.println("Error: action is invalid");
			}
		}
	
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines =new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
