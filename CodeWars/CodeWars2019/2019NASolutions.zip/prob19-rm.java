import java.io.FileInputStream;//required for I/O from file
import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
/**
 * PROBLEM: Simple String Encryption
 * DIFFICULTY LEVEL: Intermediate (For high school students, encryption problems are one of the most difficult to solve for beginners)
 * ESTIMATED COMPLETION TIME NEEDED: 25-40 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-13
 * WHAT IT TESTS: 
 * 	1.) Ability to understand and implement concept of encryption (we are just scratching the surface here with an elementary introduction level problem for encryption, but this will still be very complicated for beginning high school students)
 * 	2.) Ability to understand and compensate for non-printable characters in output along with ASCII values of character literals in general 
 * 	3.) Ability to understand and implement hexadecimal from decimal computations (or at least know how to use built-in library functions to do so)
 * 	4.) Ability to recognize and compensate for ranges in a numerical series which need to be adjusted for, but which cannot affect the value of the output
 *  5.) Ability to remove or ignore an item from a data set 
 * 	6.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms. 
 * PROBLEM DESCRIPTION:
We are a global multi-mega media warehouse and we need our bits encrypted!  We are looking for skilled encryptors and we've a good test to weed out the unskilled.  We look forward to your attempts!

We will give you a Password and the text to encode.  If your encoding matches our expectations, we will gladly reward you by further considering your efforts.

First, create an integer "key" from the password by parsing each character in the password: take the ASCII value of each character and alternately add and subtract each, starting with addition.  (In case you don't know the ASCII values, upper-case A-Z are 65-90, and lower-case a-z are 97-122.)  If the calculated key is less than 32, add 32 to the value until it is greater than or equal to 32. If the calculated key is greater than 126, subtract 16 from the value until it is less than or equal to 126. 

Example key from password: ABC  (A=65, B=66, C=67)

    key = 0 + 65 - 66 + 67
    key = 66 

Next, to encrypt the string, take each character in the string and multiply the ASCII value of the character by the key, then convert the product to base-16. 

## Input
The first line of the input will be the password to use.  All remaining lines will be strings to encrypt. 

	PASSWORD
	Hello
	World

## Output
Output the key, and each base-16 encrypted string in a comma delimited list with no spaces.  

	Key = 37
	a68,e99,f9c,f9c,100b
	c93,100b,107a,f9c,e74
 * 
 * Unicode characters WILL work with the solution, provided that the student shifts to hexadecimal accordingly and 
 * accounts for the values which will result in non-printable characters.
 * None of the provided solution sets explore unicode
 */
public class prob19 {
	/* SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.)tests a string with all of the letters of the alphabet
	 * 2.)tests multiple line handling which includes punctuation
	 * 3.)tests multiple line handling with a more complex password, and numbers to encrypt along with letters and punctuation
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 4.)tests the entire range of printable ASCII characters range 32->126
	 * 5.)tests having a blank line in the middle of the set to encrypt
	 * 6.)tests special characters in password
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * max hex 2 digits == 256
	 * min hex 2 digits == 0
	 * smallest printable traditional ASCII character = 32
	 * largest printable ASCII =  126
	 *  
	 * EDGE CASES:
	 * Password: AZ, goes negative
	 * Password: AA == zero, divide by zero problem
	 * Password: AZZA, goes below 32
	 * Password: ZAZAZ, goes over 126
	 *  
	 * This provided solution includes a decrypt function as well, so testing can run in reverse order to ensure the algorithm is working 
	 * (implementation is commented out)
	 *  
	 *  The solution only uses libraries found in the standard Java Developer Kit (JDK), no external modules or 3rd party libraries are used.*/
	public static void main(String[] args){
		try
		{
			runP1_Encrypt();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	private static void runP1_Encrypt()
	{
		//PARSE THE DATA IN
		//production
		//List<String> lines = readFromFileInputByCommandLine();
		//debugging
		List<String> lines = readFromFileToArrayList("C:\\Users\\mcadamsr\\Desktop\\CodeWars\\2019DifficultProblems\\GitHubSubmitted\\probAD-Simple-Encryption-McAdams\\example.txt");
		
		String password = lines.get(0);
		lines.remove(password);
		//PROCESS THE DATA
		System.out.println("Key = "+calculateKey(password));
		for(String line: lines)
		{
			//System.out.println("Encrypting: "+line);
			String encrypted = encryptStr(line, password);
			//encrypted
			System.out.println(encrypted);
			//System.out.println("Decrypted:  "+decryptStr(encrypted, password));
		}
	}
	private static String encryptStr(String input, String password)
	{
		String result = "";
		for (int i=0;i<input.length();i++)
		{
			int c = input.charAt(i);
			int key = calculateKey(password) * c;
			if (result.isEmpty())
			{
				result += Integer.toHexString(key);
			}
			else
			{
				result += ","+Integer.toHexString(key);
			}
		}
		return result;
	}
	private static String decryptStr(String input, String password)
	{
		String result = "";
		if (input.length() > 0)
		{
			String[] encrypted = input.split(",");
			for(int i=0;i<encrypted.length;i++)
			{
				int c = Integer.parseInt(encrypted[i],16);//convert hex back to decimal
				int div = c/calculateKey(password);
				result += (char)div;
			}
		}
		return result;
	}
	private static int calculateKey(String password)
	{
		int key = 0;
		for (int i=0;i<password.length();i++)
		{
			if (i % 2==0)
			{
				key += password.charAt(i);
			}
			else
			{
				key -= password.charAt(i);
			}
		}
		if (key < 32)
		{
			while (key < 32)
			{
				key+=32;
			}
		}
		else if (key > 126)
		{
			while (key > 126)
			{
				key-=16;
			}
		}
		return key;
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
