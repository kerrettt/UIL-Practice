#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MOVES 5
#define BUFLEN 80

char results[MOVES][MOVES][BUFLEN] = {
"TIE, SCISSORS does not effect SCISSORS",
"SCISSORS WINS, Scissors cuts Paper",
"SCISSORS LOSES, Rock crushes Scissors",
"SCISSORS WINS, Scissors decapitates Lizard",
"SCISSORS LOSES, Spock smashes Scissors",

"PAPER LOSES, Scissors cuts Paper",
"TIE, PAPER does not effect PAPER",
"PAPER WINS, Paper covers Rock",
"PAPER LOSES, Lizard eats Paper",
"PAPER WINS, Paper disproves Spock",

"ROCK WINS, Rock crushes Scissors",
"ROCK LOSES, Paper covers Rock",
"TIE, ROCK does not affect ROCK",
"ROCK WINS, Rock crushes Lizard",
"ROCK LOSES, Spock vaporizes Rock",

"LIZARD LOSES, Scissors decapitates Lizard",
"LIZARD WINS, Lizard eats Paper",
"LIZARD LOSES, Rock smashes Lizard",
"TIE, LIZARD does not effect LIZARD",
"LIZARD WINS, Lizard poisons Spock",

"SPOCK WINS, Spock smashes Scissors",
"SPOCK LOSES, Paper disrpoves Spock",
"SPOCK WINS, Spock vaporizes Rock",
"SPOCK LOSES, Lizard poisons Spock",
"TIE, SPOCK does not effect SPOCK"
};

char moves[MOVES][BUFLEN] = { 
"Scissors",
"Paper",
"Rock",
"Lizard",
"Spock"
};

main(argc, argv) int argc; char **argv; {

char m1[BUFLEN],m2[BUFLEN];
int g1,g2;
int i;

scanf("%s %s",(char *)&m1,(char *)&m2);
for(i=0;i<MOVES;i++) if(strcmp(m1,moves[i])==0) break; g1=i;
for(i=0;i<MOVES;i++) if(strcmp(m2,moves[i])==0) break; g2=i;
printf("%s\n",results[g1][g2]);
}
