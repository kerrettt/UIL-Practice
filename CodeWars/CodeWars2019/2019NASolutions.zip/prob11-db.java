/**
 * HPE CodeWars 2019
 * Author: Don Brace
 */
import java.util.*;

class SanFranciscoSkyline
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		int num_cols = 0;
		int num_rows = 0;
		int x, y;
		int yindex;
		int xindex;

		num_cols = scan.nextInt() + 1; // The axis is shifted over 1.
		num_rows = scan.nextInt();

		//System.out.println("Rows = " + num_rows + " Cols = " + num_cols);

		String skyLine[][] = new String[num_rows][num_cols];

		xindex = 0;
		for (y = 0; y < num_rows; y++) {
			yindex = scan.nextInt();
			String elevation = scan.nextLine();
			skyLine[0][yindex] = elevation;
			//System.out.println("yindex = " + yindex + " xindex = " + xindex + "String = " + elevation + "Line[" + skyLine[0][yindex] + "]");
		}

		for (y = num_rows - 1; y > -1; y--) {
			String s = skyLine[0][y];
			System.out.println(y + s);
		}

		for (x = 0, xindex = 0; x < num_cols; x++, xindex++) {
			if (x % 10 == 0)
				xindex = 0;
			System.out.print(xindex);
		}
		System.out.println("");
	} // main
}; // SanFranciscoSkyline

