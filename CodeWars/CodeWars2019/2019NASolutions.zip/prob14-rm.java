import java.io.FileInputStream;//required for I/O from file
import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
/**
 * PROBLEM: Phi won't fly for pi
 * DIFFICULTY LEVEL: LOW
 * ESTIMATED COMPLETION TIME NEEDED: 3-8 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-26
 * WHAT IT TESTS: 
 * 1.  Ability to work with floating point decimal data types
 * 2.  Ability to handle an arbitrarily large list of numbers
 * 3.  Ability to keep track of 2 elements from an arbitrarily large list of numbers
 * 4.  Ability to implement an algorithm.
 *  
 * PROBLEM DESCRIPTION: 
 * 
 * The Da Vinci Code claims that the Fibonacci sequence, also known at the golden ratio, unlocks the meaning of life, the universe, and everything. You don't believe that, but your painter does. The artist you've hired to paint your wall plans to do so as a series of expanding blocks in alternating black and white paint. Your painter has the vision, but you get to do the math!
 * 
 * The standard Fibonacci sequence is:
 * 
 * 	0,1,1,2,3,5,8,13,21...
 * 
 * The sequence is created by simply adding the sum of the prior 2 entries in the sequence together. The formula is:
 * 
 * 	F(n) = F(n-1) + F(n-2), for n > 1; assuming F(0)=0, and F(1)=1 unless otherwise stated.
 * 	
 * However, your painter hasn't decided whether to start painting at the first few blocks, or until later, so they want you to run calculations with various starting values for the sequence.
 * 
 * For example, if the sequence is started with F(0)=1 and F(1)=2, then the first few numbers in the sequence would be:
 * 
 * 		1,2,3,5,8,13...
 * 		Which is just shifted a bit to the right.
 * 
 * Your calculations must be able to accept any starting value for F(0) and F(1) for the Fibonacci sequence. You will receive 3 numbers on 3 lines. The first number on the first line will be F(0). The 2nd will be F(1), and the 3rd will be F(n) (e.g. how many numbers in the sequence to generate).
 * 
 * ## Example Input
 * 
 * 	2
 * 	4
 * 	10
 * 
 * ## Example Output
 * 
 * 	2,4,6,10,16,26,42,68,110,178
 * 	
 * */
public class prob14 {
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Base case, using the standard F(0) and F(1), asking for one element more than the problem statement gives
	 * 2.) Factors of 5 case, F(0)=5, F(1)=10
	 * 3.) Factors of 3 case, F(0)=0, F(1)=3
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Factors of 4 case, F(0)=4, F(1)=16
	 * 2.) Factors of 2 case, F(0)=2, F(1)=12
	 * 3.) Factors of 7 case, F(0)=4, F(1)=49
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * This one should be FUN! :D
	 * The algorithm is simple and straight-forward, and by shifting it around with different
	 * starting values provides just enough challenge to make it non-trivial, but still simple
	 * enough to be fun while doing it.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run_();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results.
	 * */
	private static void run_() {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\CodeWars2019\\probBH-Calc-Fibonacci-McAdams\\probBH-judge-3-in.txt");
		//PROCESS THE DATA
		int counter = 0;
		int F0 = 0;
		int F1 = 1;
		int n = 10;
		for(String line:lines){
			counter++;
			if (counter == 1){
				F0 = Integer.parseInt(line);
			}
			else if (counter == 2){
				F1 = Integer.parseInt(line);
			}
			else if (counter == 3){
				n = Integer.parseInt(line);
			}
		}
		List<Integer> sequence = new ArrayList<Integer>();
		sequence.add(F0);
		sequence.add(F1);
		for (int i =2; i< n; i++)
		{
			int next = sequence.get(i-1) +sequence.get(i-2);
			//debug
			//System.out.println("i="+i+"="+next);
			sequence.add(next);
		}
		int count = 0;
		for(int i:sequence){
			count++;
			System.out.print(""+i);
			if (count != sequence.size())
			{
				System.out.print(",");
			}
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
