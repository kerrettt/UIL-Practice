import java.io.FileInputStream;//required for I/O from file
import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
/**
 * PROBLEM: 
 * DIFFICULTY LEVEL: MEDIUM
 * ESTIMATED COMPLETION TIME NEEDED: 8-12 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-07  
 * WHAT IT TESTS: 
 * 	1.) Ability to handle multiple inputs that map to the same output
 * 	2.) Ability to keep track of data in memory that can change via user input
 * 	3.) Ability to use data from memory that is subject to change
 * 	4.) Ability to implement math functions that will take an unknown set of inputs
 * 	5.) Ability to handle user input data and clean it as needed
 * 	6.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
 * You have been put on the digital assistant "AI" team for a new phone company.
 * Your director wants to do a voice test so they can start interviewing voice actors, so your team needs to
 * create a simple "AI" script that will respond to certain inputs. The name of the "AI" assistant hasn't
 * been decided on yet, so it is subject to change.
 * 
 * For instance, if the user says to the assistant:
 * 
 * 	I'm cold
 * 
 * The assistant should reply with:
 * 
 * 	Temperature has been raised, OwnerName
 * 
 * The assistant will need to respond to some variations of some spoken commands. Below is a table with all of
 * the spoken commands your "AI" script will need to respond to, along with any variations, and the expected
 * response and action (if any).
 * 
 * COMMAND                           | ALT                             | RESPONSE                                 | ACTION
 * ----------------------------------|---------------------------------| -----------------------------------------|---------------------------------------
 * Hey AI, what's 3 plus 4?          |what's 3 added to 4?             |# plus 4 is #, [OwnerName]                |
 * Hey AI, what's 3 times 4?         |what's 3 multiplied by 4?        |# times # is #, [OwnerName]               |
 * Hey AI, what's 3 to the 4th power?|what's 3 raised to the 4th power?|# to the power of # is #, [OwnerName]     |
 * Hey AI, I'm [still] cold          |Turn up the heat                 |Temperature has been raised, [OwnerName]  |Increment room temperature value by one
 * Hey AI, I'm [still] hot           |Turn up the AC                   |Temperature has been lowered, [OwnerName] |Decrement room temperature value by one
 * Hey AI, what's the current temp?  |what's the current temperature?  |The current temperature is #, [OwnerName] |
 * Hey AI, call me Dave from now on  |                                 |Okay, I'll call you Dave from now on      |Change owner name value to new name given in command
 * Hey AI, what's your name?         |                                 |My name is [AI], [OwnerName]              |Change "AI" name value to new name given in command
 * Hey AI, can I call you Computer?  |                                 |Okay, you can call me Computer from now on|
 * Hey AI, tell me a joke            |                                 |So this guy, a squirrel, and a dog walk into a bar...|
 * Hey AI, tell me a better joke     |                                 |No                                        |
 * Hey AI, open the pod bay doors    |                                 |I can't do that, [OwnerName]              |
 *
 * Notes:
 * 	
 * If the command has a word in [brackets], that means the word is optional
 * All commands CAN start with "Hey AI-Name," but are not required to
 * You will be given a starting room temperature, an owner name, and a name for the "AI" in your script's data file
 * You will need to handle the commands using the name for the "AI" given in the data file
 * You will need to use the owner name given in the data file (shown as [OwnerName] in the expected reponse)
 * If the command is given to change the owner or "AI's" name, from that point forward you will need to use the altered name(s)
 * For the responses for your "AI" script, replace the # symbol with an integer with an appropriate value for the command
 * If the command is not understood by the "AI" script, repond with: I don't understand you, [OwnerName]
 *  	
 * ## Example In: 
 *
 * 	START_TEMP 78
 * 	NAME_OWNER Dave
 * 	NAME_AI HAL
 * 	What's your name?
 * 	Hey Dave, Can I call you Computer?	
 * 	Hey Computer, What's 3 to the 4th power?
 * 	Hey Computer, What's the current temp?	
 * 	Turn up the heat
 * 	Hey Computer, I'm still cold
 * 	What's the current temp?
 * 	Open the pod bay doors
 * 
 * ## Example Out:
 * 	My name is HAL, Dave
 * 	Okay, you can call me Computer from now on
 * 	3 to the power of 4 is 81, Dave
 * 	The current temperature is 78, Dave
 * 	Temperature has been raised, Dave
 * 	Temperature has been raised, Dave
 * 	The current temperature is 80, Dave
 * 	I can't do that, Dave
 * */
public class prob27 {
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Tests all 3 math commands (in an evil way, all answers will be the same), and joke command
	 * 2.) Tests owner name change, temp lowering (all variations), and current temp commands
	 * 3.) Tests all 3 math commands (zero operations, and power of 1), current temp, owner name change, AI name ID, AI name change, and joke command
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Tests temperature raising (all variations) and current temp commands
	 * 2.) Tests: pod bay doors, addition (negative number), both jokes, AI name ID, AI name change, current temp, temp raising commands
	 * 3.) Tests unknown command response
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * This is a problem which seems difficult at first glance, but is, in reality, a simple
	 * logic tree problem. The only curveballs thrown into it are the variations on commands
	 * and handling the math operations properly (which is why division wasn't thrown into the mix ^_^).
	 * 
	 * The solution can be brute-forced using exact matching of phrases. The solution coded here
	 * uses a slightly more advanced methodology with some pattern matching and some regular
	 * expressions used to filter the input a bit. But an elegant solution isn't needed.
	 * All of the commands were chosen so that you can simply "listen" for specific key words
	 * in the command, and respond with the appropriate response. Even the length of the commands
	 * list seems worse than it is. Half of the commands are simple 1-off operations, the rest
	 * are simple commands that follow a predictable structure.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run_();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results.
	 * */
	private static void run_() {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\CodeWars2019\\probAO-AI-Assistant-Actions-Responses-McAdams\\probAO-judge-3-in.txt");
		int startTemp = 0;
		String ownerName = "";
		String AIName = "";
		
		//PROCESS THE DATA
		int indx = 0;
		for(String line:lines){
			line = line.replaceAll("Hey "+AIName+", ", "");
			line = line.replaceAll("[^a-zA-Z0-9\\-\\s]", "");
			line = line.replaceAll("Whats", "").replaceAll("What is", "");
			line = line.replaceAll("whats", "").replaceAll("what is", "");
			String[] parts = line.trim().split(" ");
			if (indx==0){
				startTemp = Integer.parseInt(parts[1]);
				indx++;
				continue;
			}
			else if (indx==1){
				ownerName = parts[1];
				indx++;
				continue;
			}
			else if (indx==2){
				AIName = parts[1];
				indx++;
				continue;
			}
			else if (line.indexOf("plus") >=0 ||line.indexOf("added") >=0){
				AddOperation(line, parts, ownerName);
			}
			else if (line.indexOf("times") >=0 ||line.indexOf("multiplied") >=0){
				MultiplyOperation(line, parts, ownerName);
			}
			else if (line.indexOf("power") >=0 ||line.indexOf("raised") >=0){
				PowerOperation(line, parts, ownerName);
			}
			else if (line.indexOf("cold") >=0 ||line.indexOf("heat") >=0){
				startTemp++;
				System.out.println("Temperature has been raised, "+ownerName);
			}
			else if (line.indexOf("hot") >=0 ||line.indexOf("AC") >=0){
				startTemp--;
				System.out.println("Temperature has been lowered, "+ownerName);
			}
			else if (line.indexOf("current temp") >=0 ||line.indexOf("temperature") >=0){
				System.out.println("The current temperature is "+startTemp+", "+ownerName);
			}
			else if (line.indexOf("Call me") >=0 || line.indexOf("call me") >=0){
				ownerName = parts[2];
				System.out.println("Okay, I'll call you "+ownerName+" from now on");
			}
			else if (line.indexOf("your name") >=0){
				System.out.println("My name is "+AIName+", "+ownerName);
			}
			else if (line.indexOf("call you") >=0){
				AIName = parts[4];
				System.out.println("Okay, you can call me "+AIName+" from now on");
			}
			else if (line.indexOf("better") >=0){
				System.out.println("No");
			}
			else if (line.indexOf("joke") >=0){
				System.out.println("So this guy, a squirrel, and a dog walk into a bar...");
			}
			else if (line.indexOf("pod bay doors") >=0){
				System.out.println("I can't do that, "+ownerName);
			}
			else{
				System.out.println("I don't understand you, "+ownerName);
			}
		}
	}
	private static void AddOperation(String line, String[] parts, String ownerName){
		int rightIDX = 2;
		if (line.indexOf("added") >=0){
			rightIDX = 3;
		}
		int left = Integer.parseInt(parts[0]);
		int right = Integer.parseInt(parts[rightIDX]);
		System.out.println(left+" plus "+right +" is "+(left+right)+", "+ownerName);
	}
	private static void MultiplyOperation(String line, String[] parts, String ownerName){
		int rightIDX = 2;
		if (line.indexOf("multiplied") >=0){
			rightIDX = 3;
		}
		int left = Integer.parseInt(parts[0]);
		int right = Integer.parseInt(parts[rightIDX]);
		System.out.println(left+" times "+right +" is "+(left*right)+", "+ownerName);
	}
	private static void PowerOperation(String line, String[] parts, String ownerName){
		int rightIDX = 3;
		if (line.indexOf("raised") >=0){
			rightIDX = 4;
		}
		line = line.replaceAll(" power", "");
		int left = Integer.parseInt(parts[0]);
		int right = Integer.parseInt(parts[rightIDX].replaceAll("[^0-9\\s]", ""));
		double leftD = Double.parseDouble(""+left);
		double rightD = Double.parseDouble(""+right);
		System.out.println(left+" to the power of "+right +" is "+Math.round(Math.pow(leftD, rightD))+", "+ownerName);
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
