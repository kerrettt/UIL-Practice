import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
/**
 * PROBLEM: Character Counter
 * DIFFICULTY LEVEL: LOW-MEDIUM
 * ESTIMATED COMPLETION TIME NEEDED: 10-20 minutes (assuming a team of 3-4 with access to all standard documentation for their chosen language)
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-19
 * WHAT IT TESTS: 
 * 	1.) Ability to compute mathematical values in bits vs. bytes
 * 	2.) Ability to implement ascending and descending sorting
 * 	3.) Ability to maintain multiple collections of data at the same time
 * 	4.) Ability to handle character ASCII case values in an algorithm
 * 	5.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
  * You are part of a new team tasked with coming up with a shortcut keyboard to be implemented on a wrist-panel for astronauts on the first extra-galactic space flight mission. Space command has tasked your team with researching a new keyboard layout to replace QWERTY. Dvorak has already been eliminated.
 * 
 * Space is limited on the wrist-panels, so only a few letters will be visible at a time.  Your team wants to sample real messages the astronauts are sending each other now and determine which characters are used the most.
 * 
 * Your program will need to read a string of letters and spaces and count how often each character is used. Then print the characters in descending ASCII order. (ASCII 'A' is 65. 'a' is 97. A space is 20.)  If any character repeats 10 or more times, move that character to a new list instead, and sort that list in ascending ASCII order.
 * 
 * ## Input
 * Input is a single line of input between 1 and 256 characters.
 * 
 * ## Output
 * Output on a single line all characters in the sorted lists with the character followed immediately by the count of that character in square brackets ([]).  Separate the two lists with a semi-colon.  For the space character, use the underscore character (_).  For example: 
 *     
 *     ccooo DEEEEEEEEEE
 *     o[3]c[2]D[1]_[1];E[10]
 * 
 * If no character repeats 10 times, still print the semi-colon at the end of the output. Conversely, if you only have characters that repeat 10+ times, start the output with the semi-colon.
 * ###Example Input
 * 	I am the very model of a modern Major General Ive information vegetable animal and mineral Im very well acquainted too with matters mathematical I understand equations both the simple and quadratical
 * ###Example Output
 * 	y[2]w[2]v[4]u[4]s[4]q[3]p[1]j[1]h[5]g[1]f[2]d[8]c[3]b[2]M[1]I[4]G[1];_[31]a[22]e[20]i[10]l[10]m[11]n[12]o[10]r[10]t[15]
 * */
public class prob17 {
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Standard test of all available characters, does not include any character counts >= 10
	 * 2.) Standard test of character grouping, only includes character counts >= 10
	 * 3.) Large test of character grouping, in a real message, includes character counts under and over the 10 limit for grouping
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Large test of character grouping, with real text, includes character counts under and over the 10 limit for grouping
	 * 2.) Large test of character grouping, with real text, includes character counts under and over the 10 limit for grouping
	 * 3.) Large test of character grouping, with real text, includes character counts under and over the 10 limit for grouping
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			runP6_StringSorter();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results.
	 * */
	private static void runP6_StringSorter() {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\CodeWars2019\\probAJ-judge-3-in.txt");
		String input = lines.get(0);
		//PROCESS THE DATA
		List<String> buffer = new ArrayList<String>();
		List<String> list1 = new ArrayList<String>();
		List<String> list2 = new ArrayList<String>();
		for(int i=0;i<input.length();i++){
			buffer.add(input.substring(i, i+1));
		}
		Map<String,Integer> count = new HashMap<String, Integer>();
		for(String s:buffer){
			if (count.containsKey(s)){
				int c = count.get(s);
				count.replace(s, ++c);
			}
			else{
				count.put(s, 1);
			}
		}
		for (Map.Entry<String, Integer> item : count.entrySet()) {
			//System.out.println("Item : " + item.getKey() + " Count : " + item.getValue());
			if (item.getValue() >= 10){
				list2.add(item.getKey());
			}
			else{
				list1.add(item.getKey());
			}
		}
		Collections.sort(list1, Collections.reverseOrder());
		Collections.sort(list2);
		for(int i=0; i< list1.size(); i++){
			System.out.print(list1.get(i).replace(' ', '_')+"["+count.get(list1.get(i))+"]");	
		}
		System.out.print(";");
		for(int i=0; i< list2.size(); i++){
			System.out.print(list2.get(i).replace(' ', '_')+"["+count.get(list2.get(i))+"]");	
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}

}
