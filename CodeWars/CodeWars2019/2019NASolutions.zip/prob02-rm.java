import java.io.FileInputStream;//required for I/O from file
import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
/**
 * PROBLEM: Will you make it?
 * DIFFICULTY LEVEL: LOW
 * ESTIMATED COMPLETION TIME NEEDED: 3-5 minutes
 * PROBLEM AUTHOR: Ken Duisenberg, ken.duisenberg@hpe.com  
 * SOLUTION AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-25
 * WHAT IT TESTS: 
 * 1.  Ability to work with floating point decimal data types
 * 2.  Ability to read in a line of text and parse it
 * 3.  Ability to correctly divide integers and examine output
 * 4.  Ability to implement an algorithm.
 *  
 * PROBLEM DESCRIPTION: 
 * 
 * #Will You Make it?
 * 
 * What a nightmare! You woke up late and still have to travel to CodeWars. Do you have time?
 * 
 * ## Input Example 1
 * 
 * Read 3 integers on one line separated by spaces "H M S", representing the Hours until CodeWars starts, the miles you need to travel, and your speed in miles per hour.
 * 
 * 	25 100 4
 * 
 * ## Output Example 1
 * 
 * Repeat the input, then add a period and space and either "I will make it!" or "I will be late!"
 * 
 * 	25 100 4. I will make it!
 * 
 * ## Input Example 2
 * 
 * 	2 60 29
 * ## Output Example 2
 * 
 * 	2 60 29. I will be late!
 * 
 * ## Input Example 3
 * 
 * 	3 2 1
 * ## Output Example 3
 * 
 * 	3 2 1. I will make it!
 * 
 * */
public class prob02 {
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Simple data set
	 * 2.) Simple data set
	 * 3.) Will generate a non-integer answer less than 1, possible issue if not handled correctly
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Simple data set
	 * 2.) Simple data set
	 * 3.) Will generate a number which matches the "time requirement" up to the 2nd decimal place, will cause possible issues
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * No real challenge here unless the student doesn't have basic math skills.
	 * Biggest possible problem would be "close but not quite" situation if the student is 
	 * prematurely rounding before comparison.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run_();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results.
	 * */
	private static void run_() {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\CodeWars2019\\probBL-Will-You-Make-It-2pts-McAdams\\probBL-judge-3-in.txt");
		//PROCESS THE DATA
		if (lines.size() > 0){
			String[] data = lines.get(0).split(" ");
			if (data.length >2){
				double hours = Double.parseDouble(data[0]);
				double miles = Double.parseDouble(data[1]);
				double speed = Double.parseDouble(data[2]);
				if (speed != 0){
					double time = miles/speed;
					if (time <= hours){
						System.out.println(lines.get(0) + ". I will make it!");
					}
					else{
						System.out.println(lines.get(0) + ". I will be late!");
					}
				}
			}
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
