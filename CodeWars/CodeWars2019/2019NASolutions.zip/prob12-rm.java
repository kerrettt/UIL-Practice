import java.io.FileInputStream;//required for I/O from file
import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
/**
 * PROBLEM: There's always room for Pi
 * DIFFICULTY LEVEL: LOW
 * ESTIMATED COMPLETION TIME NEEDED: 3-8 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-20
 * WHAT IT TESTS: 
 * 	1.) Ability to work with floating point decimal data types
 * 	2.) Ability to handle division with floating point numbers
 * 	3.) Ability to implement an algorithm.
 *  
 * PROBLEM DESCRIPTION: 
 * 
 * The captain of your starship needs you to check the access tubes for the garbage chute. Since you have no intention of climbing around down there (lest you run into an angry Wookie climbing out), you have decided to write a program to check the tubes using drones. Before you send your drone down there though, you need to check if it will fit. The access tubes are circular, so you'll need to have your program calculate Pi while it flies. In order to save time, you will set your algorithm precision so it will run faster in larger tubes. You'll check the output of your program by looking at a random digit after it is done calculating, and comparing it against the expected digit.
 * 
 * You plan to implement Nilakantha's Series to calculate Pi.
 * The series is:
 * 
 * 	Pi = 3 + (4/2*3*4) - (4/4*5*6) + (4/6*7*8) - (4/8*9*10) + ...
 * 
 * Generic formula:
 * 	
 * 	n = 1000 //the number of times to iterate over the series
 * 	sign = 1 //determines whether or not to add or subtract
 * 	Pi = 3 //base starting value of Pi
 * 	
 * 	Loop from i=2 until (n*2)
 * 		If sign is 1
 * 			Add (4/i*(i+1)*(i+2)) to Pi
 * 		else
 * 			Subtract (4/i*(i+1)*(i+2)) from Pi
 * 		Multiply sign by negative 1
 * 		Add 2 to i 
 * 	End Loop
 * 	
 * ## Input
 * 
 * 	Line 1 will contain the value for n. Your program will need to run for that number of
 * 	iterations.
 * 	Line 2 will contain the decimal digit to output. Your program may calculate something
 * 	like: 3.141592653589787, but you should only output the decimal digit asked for in the input
 * 	
 * 	200000
 * 	14
 * 
 * ## Output
 * 
 * 	If you only calculate Pi with 200000 iterations, it will only be accurate to the 13th
 * 	decimal place. All of the other digits will be wrong. But that's fine, because you
 * 	don't need high accuracy for the larger tunnels you're sure your drone will fit in.
 * 	
 * 	8
 * 	
 * */
public class prob12 {
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Will generate 1.33333... shows why many iterations are important for accuracy
	 * 2.) Another low precision result, changing the decimal to further out
	 * 3.) Much higher precision, asking for the final (15th) decimal, which will be wrong
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Very high precision, only real variable is which decimal digit is being asked for
	 * 2.) Again, only real variable is which decimal digit is being asked for
	 * 3.) Lower precision, but pi should still mostly still be correct up to 14/15th decimal, just randomizing which digit to output
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * Simple math problem. The entire algorithm is given, all that is left is to implement it
	 * The only variable is therefore the output of the decimal digit, which may pose a problem
	 * in some languages, depending on the default decimal count for the language.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run_();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results.
	 * */
	private static void run_() {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\CodeWars2019\\probBF-Calc-Pi-McAdams\\probBF-judge-3-in.txt");
		double s = 1;//Signal for the next operation
		double pi = 3;//establishing all of the numbers as doubles so Java will behave itself when doing division
		double one = 1;
		double two = 2;
		double four = 4;
		int n = 0;
		int digit = 0;		
		//PROCESS THE DATA
		int counter = 0;
		for(String line:lines){
			if (counter==0){
				n = Integer.parseInt(line);
			}
			else{
				digit = Integer.parseInt(line);
			}
			counter++;
		}
		//Nilakantha's Series
		//pi = 3 + (4/2*3*4) - (4/4*5*6) + (4/6*7*8) - (4/8*9*10) + ...
		for (int i = 2; i <= (n*2); i+=2){
			double current = (double)i;
			pi = pi + s * (four / (current * (current + one) * (current + two)));
			s = -1 * s;
		}
		//double will only output 15 decimal places.
		//would need to set scale on division with BigDecimal to get more than 16 decimal points
		String piString = ""+pi;
		//debug
		//System.out.println(piString);
		String[] output = piString.split("|");//will split up the string to each individual character
		System.out.println(output[digit+1]);//because we want only the decimals, and we are including the leading whole number and the decimal, all we need to do is add one to have the right index
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
