#include <stdio.h>
#include <stdlib.h>

int main(argc, argv) int argc; char **argv; {
int f[2];
int i,j,k;
scanf("%d",&f[0]);
scanf("%d",&f[1]);
scanf("%d",&i);
printf("%d,%d",f[0],f[1]);
for(j=2;j<=i;j++) {
 k=f[0]+f[1];
 f[0]=f[1];
 f[1]=k;
 printf(",%d",k);
 }
printf("\n");
}
