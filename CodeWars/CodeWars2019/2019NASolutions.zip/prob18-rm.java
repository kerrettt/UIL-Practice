import java.io.FileInputStream;//required for I/O from file
import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.LinkedList;
import java.util.List;//required for List generics
/**
 * PROBLEM: Fortune Teller
 * DIFFICULTY LEVEL: LOW
 * ESTIMATED COMPLETION TIME NEEDED: 10-15 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-21
 * WHAT IT TESTS: 
 * 	1.) Ability to keep track of multiple lists of information at the same time
 * 	2.) Ability to use a hash, 2-dimensional array, or multiple lists to move information into different "states" of processing
 * 	3.) Ability to control loops with either early exits, or keeping track of indexes
 * 	4.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * Code a simulation of the "MASH" (Mansion Apartment Shack House) Game.
 * 
 * Setup for the game is simple, create some categories and under each category list some options.
 * In the real game the player would then close their eyes and draw on the paper while their friend counted until they said "stop" to determine their "magic number. "
 * In the simulation you will be coding, you will simply read an input "random" number which will be the "magic number" iterator.
 * 
 * To play the game, step through each category's options until the iterator ("magic number") has been reached, eliminate the option you are on. Repeat the process until only a single option remains, then move on to the next category, and repeat.
 * 
 * Example Where Magic Number Is 4:
 * 
 *   Colors Category:
 *   Red
 *   Blue
 *   Green
 *   
 *   Starting with Red as "1", move to Blue as "2", then Green as "3", then back up to Red as "4". Red is eliminated.
 *   Start over with Blue as "1", then Green as "2", then back up to Blue as "3" then to Green as "4". Green is eliminated.
 *   Blue is the final option left under the category, so stop iterating.
 * 
 * Your game simulation will receive one data file which will list the number of options under each category as the first line. Category names will be on their own line followed by the the word "Category" and a colon. Options under a category will be on their own lines under each category. There will always be 4 categories, but the category name and options will change.
 * The "magic number" will always be last, and will be listed under the line which says "Magic Number:" and will always be 1 or greater (never zero or negative).
 * Output the player's "MASH Story" with the final option in each category.
 * 
 * ## Example In: 
 * 	
 * 	4
 * 	Degree Category:
 * 	Associates
 * 	Bachelors
 * 	Masters
 * 	Doctorate
 * 	State Category:
 * 	California
 * 	Texas
 * 	New York
 * 	Ohio
 * 	Car Category:
 * 	Tesla
 * 	Ford
 * 	Honda
 * 	Jeep
 * 	Years In College Category:
 * 	3
 * 	4
 * 	5
 * 	6
 * 	Magic Number:
 * 	3
 * 
 * ## Example Out:
 * 
 * 	Your MASH Story:
 * 	Degree - Associates
 * 	State - California
 * 	Car - Tesla
 * 	Years in College - 3
 * 	
 * */
public class prob18 {
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Tests even number magic number > count of options, and smaller option set
	 * 2.) Tests odd number magic number < count of options, and larger option set
	 * 3.) Tests LARGE magic number, makes it difficult to hand-count the result -- either trust your algorithm or you don't :D
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Tests even number magic number < count of options, and medium option set
	 * 2.) Tests odd number magic number > count of options, and medium option set
	 * 3.) Tests LARGE magic number
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * Biggest possible pain-point for this problem will be for the student to realize that
	 * they will need to have 2 "counters", one for the "magic number" being incremented
	 * and the other for the index being kept track of.
	 * 
	 * I solved it the way a student would solve it, which is essentially setting up in 
	 * memory exactly how the game would play on paper. It would actually be faster to
	 * simply figure out the ratio between the "magic number" and the list of options,
	 * to them simply mathematically figure out the output, instead of actually iterating
	 * through the lists ¯\_(^_^)_/¯
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run_();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results.
	 * */
	private static void run_() {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\CodeWars2019\\probAY-MASH-type-game-McAdams\\prob-judge-3-in.txt");

		List<String> category1 = new ArrayList<String>();
		List<String> category2 = new ArrayList<String>();
		List<String> category3 = new ArrayList<String>();
		List<String> category4 = new ArrayList<String>();
		
		List<String> categoryNames = new ArrayList<String>();
		
		int MAGIC_NUMBER = 0;
		boolean magicNumberIsNext = false;
		//PROCESS THE DATA
		int counter = 0;
		for(String line:lines){
			if (counter > 0){
				//discarding the given count of options, as the solution just counts them
				if (magicNumberIsNext)
				{
					MAGIC_NUMBER = Integer.parseInt(line.trim());
					MAGIC_NUMBER--;//make the magic number match array/list indexing
				}
				else if (line.indexOf("Magic Number:") >= 0)
				{
					magicNumberIsNext = true;
				}
				else if (line.indexOf("Category:") >= 0)
				{
					categoryNames.add(line.replaceAll(" Category:", ""));
				}
				else
				{
					if (categoryNames.size() == 1){
						category1.add(line);
					}
					else if (categoryNames.size() == 2){
						category2.add(line);
					}
					else if (categoryNames.size() == 3){
						category3.add(line);
					}
					else if (categoryNames.size() == 4){
						category4.add(line);
					}
				}
			}
			counter++;
		}
		
		List<String> dummyCategory = new LinkedList<String>();
		for (int i = 0; i < category1.size(); i++){
			dummyCategory.add(""+i);
		}
		boolean done = false;
		int index = 0;//keeps track of where we are iterating through the magic number
		int removeAt = -1;//keeps track of which index we are on as we count through the magic number
		while (!done){
			for (int i = index; i <= MAGIC_NUMBER; i++){
				index = i;
				removeAt++;
				if (removeAt > dummyCategory.size()-1){
					removeAt = 0;
				}
				//System.out.println("DEBUGGING index:"+index+", removeAt:"+removeAt);
			}
			if (dummyCategory.size() > 1){
				dummyCategory.remove(removeAt);
				//System.out.println("*****DEBUGGING REMOVING:"+removeAt);
				index = 0;
				removeAt--;
			}
			else{
				done = true;
			}
		}
		int outputIndex = Integer.parseInt(dummyCategory.get(0).trim());
		System.out.println("Your MASH Story:");
		System.out.print(categoryNames.get(0)+" - ");
		System.out.println(category1.get(outputIndex));
		System.out.print(categoryNames.get(1)+" - ");
		System.out.println(category2.get(outputIndex));
		System.out.print(categoryNames.get(2)+" - ");
		System.out.println(category3.get(outputIndex));
		System.out.print(categoryNames.get(3)+" - ");
		System.out.println(category4.get(outputIndex));
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
