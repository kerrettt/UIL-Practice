import java.io.FileInputStream;//required for I/O from file
import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
/**
 * PROBLEM: Glad to Meet You
 * DIFFICULTY LEVEL: LOW
 * ESTIMATED COMPLETION TIME NEEDED: 3-5 minutes
 * PROBLEM AUTHOR: Ken Duisenberg, ken.duisenberg@hpe.com  
 * SOLUTION AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-26
 * WHAT IT TESTS: 
 * 1.  Ability to work with integer data types
 * 2.  Ability to read in a line of text and parse it
 * 3.  Ability to correctly multiply and divide integers
 * 4.  Ability to implement an algorithm.
 *  
 * PROBLEM DESCRIPTION: 
 * 
 * # Glad to Meet You
 * 
 * Several couples have arrived at a party and everyone introduces themselves and shakes hands.
 * 
 * Being the ever diligent student of human behavior, you wonder just how many times introductions were made.
 * 
 * ## Input
 * 
 * 	Read one integer N, the number of couples who arrived. Maximum of 100 (that's a big party!)
 * 
 *     4
 * 
 * ## Output
 * 	
 * 	If everyone shakes hands once with every other person there (not shaking hands with themselves or with their date), print the number of handshakes.
 * 
 *	24
 * 
 * ## Explanation
 * 
 *	For 4 couples, call them AA, BB, CC, DD.  Both of couple AA each shake hands with BB, CC, DD, for a total of 12 handshakes.  Couple BB has already shaken hands with AA, so now shakes hands with CC and DD (8 handshakes).  Finally, Couple CC shakes hands with DD (4 handshakes.)  Total of 24 handshakes.
 * 
 * ## Example 2 Input
 * 
 * 	10
 * 
 * ## Example 2 Output
 * 
 * 	180
 * 
 * */
public class prob06 {
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Simple data set
	 * 2.) Simple data set
	 * 3.) Simple data set
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Simple data set
	 * 2.) Simple data set
	 * 3.) simple data set
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * The major sticking point here will be if a student gets confused and tries to solve it
	 * as a factorial (N!) problem, which will overflow int and long-int data types almost
	 * immediately. Everything else is standard.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run_();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results.
	 * */
	private static void run_() {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\CodeWars2019\\probBP-Handshakes-3-pts-McAdams\\probBP-judge-3-in.txt");
		//PROCESS THE DATA
		if (lines.size() > 0){
			int n = Integer.parseInt(lines.get(0));
			long handshakes = (2*n * ((2*n)-2)) / 2;
			System.out.println(""+handshakes);
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
