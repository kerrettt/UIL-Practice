import java.io.FileInputStream;//required for I/O from file
import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
import java.util.Arrays;//required to use the Arrays.asList functionality
import java.util.LinkedList;//required to implement a List which we can remove elements from (in Java, cannot remove elements from a List created from an Array.asList operation)
/**
 * PROBLEM: Too too many words
 * DIFFICULTY LEVEL: MEDIUM to HIGH (This problem can be solved using simple arrays, loops and conditionals. It can be also solved with recursion)
 * ESTIMATED COMPLETION TIME NEEDED: 20-35 minutes  
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-19
 * WHAT IT TESTS: 
 * 	1.) Ability to understand string parsing and manipulation
 * 	2.) Ability to handle index error problems while parsing arrays/lists
 * 	3.) Ability to handle off-by-one output issues
 * 	4.) Ability to anticipate and prevent infinite loops (if using loops or recursion) 
 * 	5.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms. 
 * PROBLEM DESCRIPTION:
 * You are working on on your first novel, and while the spell checking and grammar checking tools are helping a lot, one of of the things which keeps getting missed is is accidental duplicate words. You have decided to to write your own program which will remove duplicate words from your text.
 * 
 * Given an arbitrarily long string of of words, remove all duplicate words.  
 * 
 * But you must keep two special cases: "is is" and "had had". For these special exceptions, only 2 in a row are allowed.  For example, if you find "is is is", change it to "is is".
 * 
 * Ignore case of letters when comparing for duplicates. You will receive one line of input which will be a long string containing 0-256KB of letters and spaces only.  When deleting words, keep the first ones.
 * 
 * ## Input
 * 	I am Am someone who had haD HAD a dog and and knowing what that is is Is iS a a a a happy thing
 * 
 * ## Output
 * 	I am someone who had haD a dog and knowing what that is is a happy thing
 */
public class prob16 {
	/* SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.)//standard test case, contains single instance of repeated word
	 * 2.)//tests single instance of special case: had had
	 * 3.)//tests longer input, one special case of repeated 'is', with non-matching case, and several instances of repeats
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 4.)//contains both special cases, one of which has more than 2 repeats
	 * 5.)//tests totally evil implementation of repeats that should boil down to a very short sentence (this can trigger infinite loops and/or overflows (depending on language) if not coded correctly to account for the amount of repeats, and the size of the input)
	 * 6.)//tests handling of a blank line (output should be a single blank line)
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * This solution uses recursion to solve the problem, which is what this kind of problem lends itself to being solved with,
	 * but recursion is a more difficult concept for early students of programming, and it is more likely loops and conditionals 
	 * will be used by students to solve it.
	 * 
	 * The solution only uses libraries found in the standard Java Developer Kit (JDK), no external modules or 3rd party libraries are used.*/
	public static void main(String[] args) {
		try
		{
			runP3_Duplicates();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	private static void runP3_Duplicates()
	{
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\Users\\mcadamsr\\Desktop\\CodeWars\\P3In6.txt");
		//PROCESS THE DATA
		for(String line: lines)
		{
			System.out.println(removeDuplicates(line));	
		}
	}
	private static String removeDuplicates(String input)
	{
		boolean found = false;
		String[] _words = input.split(" ");
		List<String> words = new LinkedList<String>(Arrays.asList(_words));//using linked list so we can remove from it
		for (int i=0; i < words.size(); i++)
		{
			if (i>0)
			{
				String word = words.get(i); 
				if (words.get(i - 1).equalsIgnoreCase(words.get(i))) 
				{
					if ((i+1)< words.size() && (word.equalsIgnoreCase("had") || word.equalsIgnoreCase("is")))
					{
						if ((word.equalsIgnoreCase("had") || word.equalsIgnoreCase("is")) &&
							(words.get(i - 1).equalsIgnoreCase(words.get(i+1))))
						{
							words.remove(i);
							found = true;
						}
					}
					else if (!word.equalsIgnoreCase("had") && !word.equalsIgnoreCase("is")) 
					{
						words.remove(i);
						found = true;
					}
				}
			}
		}
		if (found)
		{
			String output = "";
			for(String word: words)
			{
				if (output.isEmpty())
				{
					output += word;
				}
				else
				{
					output += " "+word;
				}
			}
			return removeDuplicates(output);
		}
		else
		{
			return input;
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
