# !/bin/python3

import sys


def get_bare_oloompas(oloompas):
    offset = oloompas.find('#')
    return oloompas[offset:oloompas.rfind('#') + 1], offset


def parse(data):
    oloompas, offset = get_bare_oloompas(data[0].split()[-1])
    results = {11: int(data[1]), 1000: int(data[2])}
    notes = [d.strip() for d in data[3:-1]]

    return results, oloompas, offset, notes


def age_oloompas(oloompas, notes):
    oloompas = '....' + oloompas + '....'
    new_oloompas = ''
    for i in range(2, len(oloompas) - 2):
        if oloompas[i-2:i+3] in notes:
            new_oloompas += '#'
        else:
            new_oloompas += '.'
    oloompas, offset = get_bare_oloompas(new_oloompas)
    return oloompas, offset - 2


def get_offset(first, last, rounds, results):
    offsets = [val['offset'] for val in results.values() if first <= val['index'] <= last]
    return sum(offsets) * rounds


def get_repeat_count(curr_gen, gens, curr_oloompas, curr_offset, results):
    gens_left = gens - curr_gen

    first_oloompa = results[curr_oloompas]
    last_oloompa = max(results.values(), key=lambda p: p['index'])

    if first_oloompa == last_oloompa:
        rounds = gens_left
        remainder = 0
    else:
        round_len = last_oloompa['index'] - first_oloompa['index']
        rounds = gens_left // round_len
        remainder = gens_left % round_len
    result_index = first_oloompa['index'] + remainder

    for val in results.values():
        if val['index'] == result_index:
            result_oloompas = val
            break

    previous_offset = min([val for val in results.values() if val['oloompas'] == curr_oloompas], key=lambda p: p['index'])['offset']
    rounds_offset = last_oloompa['offset'] - previous_offset
    remainder_offset = result_oloompas['offset'] - previous_offset
    curr_offset += (rounds_offset * rounds) + (remainder_offset * remainder)

    return sum(i for i, val in enumerate(result_oloompas['oloompas'], start=curr_offset) if val == '#')


def age_gens(oloompas, offset, notes, gens):
    results = {}
    for i, _ in enumerate(range(gens), start=1):
        if oloompas in results:
            return get_repeat_count(i-1, gens, results[oloompas]['oloompas'], offset, results)
        new_oloompas, oloompa_offset = age_oloompas(oloompas, notes)
        offset += oloompa_offset
        results[oloompas] = {'index': i, 'oloompas': new_oloompas, 'offset': offset}
        oloompas = new_oloompas
    return sum([i + offset for i, val in enumerate(oloompas) if val == '#'])



if __name__ == '__main__':
    with open("prob29.txt") as f:
        data = f.readlines()
    results, oloompas, offset, notes = parse(data)

    for val, expected in results.items():
           actual = age_gens(oloompas, offset, notes, val)
           if expected != actual:
               raise Exception('{} failed. expected = {}. actual = {}.'.format(val, expected, actual))

    for val in [12, 1001, 50000000000]:
           print(age_gens(oloompas, offset, notes, val))
