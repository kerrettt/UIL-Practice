#!/usr/bin/env python
# Print the area (in square feet of grass) the goat can reach.  
# It normally would be a full circle, but two walls of the barn are 
# in the way. The rope is shorter than the walls of the barn.  
# The area of a circle with radius r is A = Pi * r * r.  Use Pi=3.14159.
import sys

line = sys.stdin.readline(3)
length = int(line)
result = length * length * 3.14159 * 0.75
print (result)