import java.io.FileInputStream;//required for I/O from file
import java.util.Scanner;//required for I/O from stdin
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
/**
 * PROBLEM: More things in heaven & earth, than poor ratios
 * DIFFICULTY LEVEL: LOW
 * ESTIMATED COMPLETION TIME NEEDED: 3-8 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-20
 * WHAT IT TESTS: 
 * 	1.) Ability to work with floating point decimal data types
 * 	2.) Ability to handle division with floating point numbers
 * 	3.) Ability to work with numbers and strings at the same time
 *  4.) Ability to implement an algorithm.
 *  
 * PROBLEM DESCRIPTION: 
 * 
 * Your last algebra test tells you that you need to work on your ability to solve ratio comparison problems. You kept getting the math wrong. So, you've decided to create a function which will take 2 ratios with an unknown variable "X" and have it solve for "X" so you can check your homework and learn how to do it properly, hopefully before the next test!
 * 
 * The formula for determining "X" when comparing two ratios is to simply take the two ratios setup as fractions, cross multiply and solve for "X". E.G.:
 * 
 * 	X/10 = 20/200
 * 	200X = 200
 * 	200X/200 = 200/200
 * 	X = 1
 * 
 * You will receive 4 lines in your input. 3 of the lines will be numbers, the 4th will simply be "X". Line 1 will be the numerator of the ratio on the left side of the equal sign. Line 2 will be its denominator. Line 3 will be the numerator on the right, and line 4 its denominator. Wherever you find "X" you will need to handle it, and solve for X.
 * 	
 * ## Input
 * 	
 * 	X
 * 	10
 * 	20
 * 	200
 * 
 * ## Input Explanation
 * 
 * 	That input should map to an equation as follows:
 * 	X/10 = 20/200
 * 	
 * ## Output
 * 
 * 	1.0
 * 
 * ## Note
 * 
 * 	Answers correct to the first decimal place will be accepted as correct
 * 	
 * */
public class prob13 {
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) X is in 3rd position, so right numerator. Answer will be a whole number
	 * 2.) X is in 2nd position, so left denominator. Answer won't be a whole number
	 * 3.) X is in 1st position, so left numerator. Answer won't be a whole number
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) X is in 4th position, so right denominator. Answer will be a whole number
	 * 2.) X is in 2nd position, so left denominator. Answer will be a whole number
	 * 3.) X is in 3rd position, so right numerator. Answer won't be a whole number
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * Requires that when reading in the lines, the student evaluates whether or not the line
	 * is a number, or a string (in this case equal to "X"), to determine how to do the math.
	 * Everything else is pretty standard, the math is shown in the problem, so all that is
	 * left to do is implement it as an algorithm.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run_();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results.
	 * */
	private static void run_() {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\CodeWars2019\\probBG-Calc-Ratio-McAdams\\probBG-judge-3-in.txt");

		int count=0;
		int Xis =0;
		double left_num = 0;
		double left_den = 1;
		double right_num = 0;
		double right_den = 1;
		//PROCESS THE DATA
		for(String line:lines){
			count++;
			if (line.equalsIgnoreCase("X")){
				Xis = count;
			}
			else if (count == 1){
				left_num = Double.parseDouble(line);
			}
			else if (count == 2){
				left_den = Double.parseDouble(line);
			}
			else if (count == 3){
				right_num = Double.parseDouble(line);
			}
			else if (count == 4){
				right_den = Double.parseDouble(line);
			}
		}
		double product = 0;
		double divisor = 1;
		if (Xis == 1){
			//x is left numerator
			product = left_den * right_num;
			divisor = right_den;
		}
		else if (Xis == 2){
			//x is left denominator
			product = left_num * right_den;
			divisor = right_num;
		}
		else if (Xis == 3){
			//x is right numerator
			product = left_num * right_den;
			divisor = left_den;
		}
		else if (Xis == 4){
			//x is right denominator
			product = left_den * right_num;
			divisor = left_num;
		}
		double result = product / divisor;
		System.out.println(""+result);
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
