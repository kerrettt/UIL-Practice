import java.io.FileInputStream;//required for I/O from file
import java.util.Scanner;//required for I/O from stdin
import java.time.LocalDate;//required for DateTime parsing
import java.time.format.DateTimeFormatter;//required for DateTime parsing
import java.time.temporal.ChronoUnit;//required for doing date length calculations
import java.util.ArrayList;//required for ArrayList generics
import java.util.List;//required for List generics
/**
 * PROBLEM: Age Calculator
 * DIFFICULTY LEVEL: VERY-LOW
 * ESTIMATED COMPLETION TIME NEEDED: 3-8 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-01
 * WHAT IT TESTS: 
 * 	1.) Ability to handle dates
 * 	2.) Ability to understand how to manipulate a date
 * 	3.) Ability to understand how to compare dates
 *  4.) Ability to create a branching logic path to handle multiple types of problems in the same space
 * 	5.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
 * [insert story ... HERE! ^_^]
 * 
 * You will need to read in a data file containing an unknown number of lines. Each line will either be two dates or a
 * date and an integer. Given a line with two dates separated by a space, calculate the age of a person taking the first 
 * date as their birth date, and the second date as the date to check their age.
 * 
 * Example:
 *  
 * 	1967-01-31 1984-01-31
 * 
 * Given a date and an integer separated by a colon, calculate what date a person will be the age given by the integer, if
 * the integer is greater than zero and less than one hundred.
 * 
 * Example:
 * 
 * 	1968-08-06:39
 * 
 * Notes on dates from your manager:
 * 	Dates will range from Jan. 1st 1583 to Dec. 31 3000.
 * 	Keep in mind leap years! If the year is evenly divisible by 4, it is a leap year. However, if the year is also divisible by 100 evenly, it is NOT a leap year (unless it is also divisible by 400).
 *
 * If the age given is zero, instead calculate the date the person will STILL be zero years old. If the age is greater than
 * 99, calculate the age as usual, but add "(good job!)" to the end of the output.
 * 
 * Output as follows: 
 *  
 * Example In:
 *  
 * 	1968-08-06:39
 * 	1967-01-31 1984-01-31
 * 	2001-08-13:99
 * 	2019-07-04:110
 * 	2005-12-24:0
 * 
 * Example Out:
 * 
 * 	Will be 39 on 2007-08-06 if born on 1968-08-06
 * 	If born on 1967-01-31, will be 17 years old on 1984-01-31
 * 	Will be 99 on 2100-08-13 if born on 2001-08-13
 * 	Will be 110 on 2129-07-04 if born on 2019-07-04 (good job!)
 * 	Will still be 0 up to 2006-12-23 if born on 2005-12-24
 * 	
 * */
public class prob10 {
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Leap year gotchas. Have to know about year %4 rule, and also century year %400 rule to roll own coding
	 * 2.) Tests simple forwards and backwards 14 years, in 2 ways, and also very old dates with very large age
	 * 3.) Tests old dates with random terminus points. Does not include the target age option for branching 
	 * 		code (to test if branching is handled correctly)
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Tests only targeting age calculation branch (inverse of student-3-in)
	 * 2.) More leap year tests (essentially the same as student-1-in, but with different dates)
	 * 3.) Standard age target tests, and also date comparison tests, except for one, which is a
	 * 		zero-year age test (but not a targeted age, so output won't be special)
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * This will be fairly trivial to solve with built-in libraries for most modern languages.
	 * The only sticking points will be the branching logic and edge cases.
	 * 
	 * The leap year problem will be what throws most students off, because if they try to
	 * simply subtract 364 days from the next year, they will be off by a day on leap years
	 * on March 1st.
	 * 
	 * If the student tries to calculate the dates manually ... things most likely won't go well,
	 * as the student data will include leap years and other "gotchas" that discourage rolling 
	 * one's own date coding (of course, if the student is using C or even C++, they have bigger
	 * problems already to deal with than the lack of a built-in robust set of date functions ^_^)
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run_();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results.
	 * */
	private static void run_() {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\CodeWars2019\\probAZ-Age-Calculator-McAdams\\prob-judge-3-in.txt");
		
		//PROCESS THE DATA
		for(String line:lines){
			if (line.indexOf(":") >= 0){
				String[] dateAndAge = line.split(":");
				int newAge = Integer.parseInt(dateAndAge[1]);
				LocalDate bornAt = LocalDate.parse(dateAndAge[0], DateTimeFormatter.ISO_DATE);
				LocalDate ageAt = null;
				if (newAge >0){
					ageAt = bornAt.plusYears(newAge);
					System.out.print("Will be "+newAge +" on "+ageAt+" if born on "+ bornAt);
					 if (newAge >99){
						 System.out.println(" (good job!)");
					 }
					 else{
						 System.out.println("");
					 }
				}
				else{
					ageAt = bornAt.plusYears(1).minusDays(1);
					System.out.println("Will still be "+newAge +" up to "+ageAt+" if born on "+ bornAt);
				}
			}
			else{
				String[] twoDates = line.split(" ");
				LocalDate bornAt = LocalDate.parse(twoDates[0], DateTimeFormatter.ISO_DATE);
				LocalDate ageAt = LocalDate.parse(twoDates[1], DateTimeFormatter.ISO_DATE);
				long years = ChronoUnit.YEARS.between(bornAt,ageAt);
				System.out.println("If born on "+bornAt + ", will be "+years+" years old on "+ageAt);
			}
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
