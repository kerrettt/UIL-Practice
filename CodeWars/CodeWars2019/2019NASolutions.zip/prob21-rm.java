import java.io.FileInputStream;//required for I/O from file
import java.util.Scanner;//required for I/O from stdin
import java.time.LocalDate;//required for DateTime parsing
import java.time.format.DateTimeFormatter;//required for DateTime parsing
import java.util.ArrayList;//required for ArrayList generics
import java.util.Arrays;//required to construct arraylist with literal array values
import java.util.List;//required for List generics
/**
 * PROBLEM: Chinese Zodiac Receipt
 * DIFFICULTY LEVEL: LOW-MEDIUM LOW
 * ESTIMATED COMPLETION TIME NEEDED: 10-15 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-01-26
 * WHAT IT TESTS: 
 * 	1.) Ability to work with dates
 * 	2.) Ability to create an algorithm to compare dates (either by hard-coded pattern matching, or with a general purpose algorithm)
 * 	3.) Ability to walk through a range of data and make a determination based on the outcome
 * 	4.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
 * You have started a job at a large food conglomerate as a computer programmer.
 * Your first assignment is to fix the output for the receipts printed for the
 * company's Chinese food restaurant division. Management wanted the receipts to
 * output the current date someone must have been born on or before to be 21
 * years of age, and to make it more fun, to print the Zodiac sign of that
 * date and also the Zodiac animal for that year. Unfortunately, the prior
 * programmer made some mistakes and the registers are crashing between mid-December
 * and mid-January. The restaurant owners are demanding the problem be fixed immediately.
 * 
 * Unfortunately nobody can find the source code for the algorithm that determines the
 * output, so you need to write it from scratch. All your code will have to do is
 * take a date sent in by the cash register's main code (as a string), and output two 
 * lines of text which the system will place at the bottom of the receipt.
 * 
 * Because the registers are sometimes placed into testing mode by the Federal
 * Department of Weights and Measures, your code will need to gracefully handle all
 * valid ISO-8601 Gregorian/Joda dates between the range of Jan. 1 1583 and Dec. 31 3001

 * To determine the Zodiac output, the rules are simple. The Zodiac animal for the year
 * rotates every 12 years. The 12 most recent animals were:
 * 
 * 	2008 - Rat
 * 	2009 - Ox
 * 	2010 - Tiger
 * 	2011 - Rabbit
 * 	2012 - Dragon
 * 	2013 - Snake
 * 	2014 - Horse
 * 	2015 - Sheep
 * 	2016 - Monkey
 * 	2017 - Rooster
 * 	2018 - Dog
 * 	2019 - Pig
 * 
 * The date ranges for the Zodiac sign of a person's birth have been determined by the
 * company's HR department to be:
 * 	
 * 	Aries	March 21 - April 19
 * 	Taurus	April 20 - May 20
 * 	Gemini	May 21 - June 20
 * 	Cancer	June 21 - July 22
 * 	Leo	July 23 - August 22
 * 	Virgo	August 23 - September 22
 * 	Libra	September 23 - October 22
 * 	Scorpio	October 23 - November 21
 * 	Sagittarius	November 22 - December 21
 * 	Capricorn	December 22 - January 19
 * 	Aquarius	January 20 - February 18
 * 	Pisces	February 19 - March 20
 * 
 * Example In: 
 * 	2019-03-02
 * 
 * Example Out:
 * 	If you were born on March 2, your sign is Pisces.
 * 	2019 is the year of the Pig.
 * */
public class prob21 {
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Testing basic date
	 * 2.) Testing date in the past, which is also a leap day
	 * 3.) Testing date in the future
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Testing date in past with same number for month and day
	 * 2.) Testing another past date
	 * 3.) Testing future date
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run_();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results.
	 * */
	private static void run_() {
		//PARSE THE DATA IN
		//production
		//List<String> lines = readFromFileInputByCommandLine();
		//debugging
		List<String> lines = readFromFileToArrayList("C:\\CodeWars2019\\prob-judge-3-in.txt");
		
		//PROCESS THE DATA
		for(String line:lines){//don't have to use a loop here since the problem specifies only one input, but for testing purposes this was easier (could test all at once)
			LocalDate inputDate = LocalDate.parse(line, DateTimeFormatter.ISO_DATE);
			String monthName = inputDate.getMonth().name().toLowerCase();
			monthName =monthName.substring(0,1).toUpperCase()+monthName.substring(1); 
			System.out.println("If you were born on "+monthName+" "+inputDate.getDayOfMonth()+", your sign is "+DetermineSign(line)+".");
			System.out.println(line.substring(0, 4)+ " is the year of the "+DetermineBirthYearAnimal(line)+".");
		}
	}
	/**
	 * Takes a date in as a string, parses it as an ISO8601 Gregorian/Joda date, then
	 * compares it to the month ranges that define a person's Zodiac "sign"
	 * and outputs the person's "sign" as a string based on where the date
	 * falls in the comparison list
	 * */
	private static String DetermineSign(String input){
		String result = "";
		LocalDate inputDate = LocalDate.parse(input, DateTimeFormatter.ISO_DATE);
		List<LocalDate> limits = new ArrayList<LocalDate>();
		limits.add(LocalDate.parse(inputDate.getYear()+"-01-01", DateTimeFormatter.ISO_DATE));//Capricorn
		limits.add(LocalDate.parse(inputDate.getYear()+"-01-19", DateTimeFormatter.ISO_DATE));
		limits.add(LocalDate.parse(inputDate.getYear()+"-01-20", DateTimeFormatter.ISO_DATE));//Aquarius
		limits.add(LocalDate.parse(inputDate.getYear()+"-02-18", DateTimeFormatter.ISO_DATE));
		limits.add(LocalDate.parse(inputDate.getYear()+"-02-19", DateTimeFormatter.ISO_DATE));//Pisces
		limits.add(LocalDate.parse(inputDate.getYear()+"-03-20", DateTimeFormatter.ISO_DATE));
		limits.add(LocalDate.parse(inputDate.getYear()+"-03-21", DateTimeFormatter.ISO_DATE));//Aries
		limits.add(LocalDate.parse(inputDate.getYear()+"-04-19", DateTimeFormatter.ISO_DATE));
		limits.add(LocalDate.parse(inputDate.getYear()+"-04-20", DateTimeFormatter.ISO_DATE));//Taurus
		limits.add(LocalDate.parse(inputDate.getYear()+"-05-20", DateTimeFormatter.ISO_DATE));
		limits.add(LocalDate.parse(inputDate.getYear()+"-05-21", DateTimeFormatter.ISO_DATE));//Gemini
		limits.add(LocalDate.parse(inputDate.getYear()+"-06-20", DateTimeFormatter.ISO_DATE));
		limits.add(LocalDate.parse(inputDate.getYear()+"-06-21", DateTimeFormatter.ISO_DATE));//Cancer
		limits.add(LocalDate.parse(inputDate.getYear()+"-07-22", DateTimeFormatter.ISO_DATE));
		limits.add(LocalDate.parse(inputDate.getYear()+"-07-23", DateTimeFormatter.ISO_DATE));//Leo
		limits.add(LocalDate.parse(inputDate.getYear()+"-08-22", DateTimeFormatter.ISO_DATE));
		limits.add(LocalDate.parse(inputDate.getYear()+"-08-23", DateTimeFormatter.ISO_DATE));//Virgo
		limits.add(LocalDate.parse(inputDate.getYear()+"-09-22", DateTimeFormatter.ISO_DATE));
		limits.add(LocalDate.parse(inputDate.getYear()+"-09-23", DateTimeFormatter.ISO_DATE));//Libra
		limits.add(LocalDate.parse(inputDate.getYear()+"-10-22", DateTimeFormatter.ISO_DATE));
		limits.add(LocalDate.parse(inputDate.getYear()+"-10-23", DateTimeFormatter.ISO_DATE));//Scorpio
		limits.add(LocalDate.parse(inputDate.getYear()+"-11-21", DateTimeFormatter.ISO_DATE));
		limits.add(LocalDate.parse(inputDate.getYear()+"-11-22", DateTimeFormatter.ISO_DATE));//Sagittarius
		limits.add(LocalDate.parse(inputDate.getYear()+"-12-21", DateTimeFormatter.ISO_DATE));
		limits.add(LocalDate.parse(inputDate.getYear()+"-12-22", DateTimeFormatter.ISO_DATE));//Capricorn
		limits.add(LocalDate.parse(inputDate.getYear()+"-12-31", DateTimeFormatter.ISO_DATE));
		List<String> Signs = Arrays.asList(new String[]{"Capricorn","Capricorn","Aquarius","Aquarius","Pisces","Pisces","Aries","Aries","Taurus","Taurus","Gemini","Gemini","Cancer","Cancer","Leo","Leo","Virgo","Virgo","Libra","Libra","Scorpio","Scorpio","Sagittarius","Sagittarius","Capricorn","Capricorn"});
		for(int i=0;i<(limits.size()-1);i+=2){
			if ((inputDate.isAfter(limits.get(i)) || inputDate.isEqual(limits.get(i)))
					&&
				(inputDate.isBefore(limits.get(i+1)) || inputDate.isEqual(limits.get(i+1))))
			{
				result= Signs.get(i);
				break;
			}			
		}
		return result;
	}
	/**
	 * Takes a date in as a string, parses it as an ISO8601 Gregorian/Joda date, then
	 * uses a simple formula to determine the Zodiac animal for the year of the date
	 * returns the name of the animal based on the year pulled from the date
	 * */
	private static String DetermineBirthYearAnimal(String input){
		String result = "";
		LocalDate inputDate = LocalDate.parse(input, DateTimeFormatter.ISO_DATE);
		int remainder = ((inputDate.getYear() + 9) % 12);
		switch(remainder)
		{
			case 1:
				result="Rat";
				break;
			case 2:
				result="Ox";
				break;
			case 3:
				result="Tiger";
				break;
			case 4:
				result="Rabbit";
				break;
			case 5:
				result="Dragon";
				break;
			case 6:
				result="Snake";
				break;
			case 7:
				result="Horse";
				break;
			case 8:
				result="Sheep";
				break;
			case 9:
				result="Monkey";
				break;
			case 10:
				result="Rooster";
				break;
			case 11:
				result="Dog";
				break;
			case 0:
				result="Pig";
				break;
			default:
				result="Error, couldn't determine year animal";
				break;
		}
		return result;
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
