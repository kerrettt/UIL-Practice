#include <stdio.h>
#include <stdlib.h>

char nums[13][256] = {
"ZERO",
"ONE",
"TWO",
"THREE",
"FOUR",
"FIVE",
"SIX",
"SEVEN",
"EIGHT",
"NINE",
"TEN",
"ELEVEN",
"TWELVE" };

char buf[256];
int f[26];


int main(argc, argv) int argc; char **argv; {
int n;
int r;
int k;
int l,m;

for(n=0;n<26;n++) f[n]=0;
fgets(buf,256,stdin);
for(n=0;n<256;n++) if(buf[n]=='\n') buf[n]='\0';
k=r=0;
while(sscanf(&buf[k],"%d%n",&n,&r),n!=999) {
 for(l=0;nums[n][l];l++)
  f[nums[n][l]-'A']++;
 k+=r;
}
printf("%s.",buf);
for(n=0;n<26;n++)
 for(k=0;k<f[n];k++)
  printf(" %c",n+'A');
printf("\n");
}
