import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
/**
 * PROBLEM: Rock Paper Scissors Lizard Spock
 * DIFFICULTY LEVEL: LOW
 * ESTIMATED COMPLETION TIME NEEDED: 5-10 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-11
 * WHAT IT TESTS: 
 * 	1.) Ability to conditionally output based on changing criteria
 * 	2.) Ability to pattern match
 * 	3.) Ability to implement data lookups (either via an index/hash, or via hard-coding)
 * 	4.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * 
 * Implement the game: Rock Paper Scissors Lizard Spock
 * 
 * The Rules Are:
 * 	Scissors cuts Paper
 * 	Paper covers Rock
 * 	Rock crushes Lizard
 * 	Lizard poison Spock
 * 	Spock smashes Scissors
 * 	Scissors decapitates Lizard
 * 	Lizard eats Paper
 * 	Paper disproves Spock
 * 	Spock vaporizes Rock
 * 	Rock crushes Scissors
 * 
 * You will receive the choices from both players at the same time in the form of:
 * 	Choice1 Choice2
 * 
 * You are guaranteed to only receive one game choice at a time.
 * You are guaranteed that the game choice will be formatted properly, and will exist.
 * 
 * If the same choice is made for both sides, the result is a tie.
 * State the winner in terms of the first choice made (the choice to the left of the space).
 * Else, state the outcome and the winner.
 *  
 * Example In: 
 * 	Scissors Lizard
 * 
 * Example Out:
 *  SCISSORS WINS, Scissors decapitates Lizard
 *  
 * Example In 2: 
 * 	Scissors Rock
 * 
 * Example Out 2:
 *  SCISSORS LOSES, Rock crushes Scissors
 * 
 * Example In 3: 
 * 	Spock Rock
 * 
 * Example Out 3: 
 *  TIE, ROCK does not effect ROCK
 * ----------------------------------------------------
 * Game source: http://samkass.com/theories/RPSSL.html
 * Game license: https://creativecommons.org/licenses/by-nc/3.0/
 * */
public class prob09 {
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Testing tie outcome
	 * 2.) Testing first choice wins
	 * 3.) Testing second choice wins
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Testing second choice wins
	 * 2.) Testing tie outcome
	 * 3.) Testing first choice wins
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			run_();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results.
	 * */
	private static void run_() {
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\CodeWars2019\\prob-student-3-in.txt");
		
		Map<String,Integer> RULES = new HashMap<String, Integer>();
		//1==1st choice wins, 0==1st choice loses, -1 -== tie
		RULES.put("Rock Paper", 0);
		RULES.put("Rock Scissors", 1);
		RULES.put("Rock Lizard", 1);
		RULES.put("Rock Spock", 0);
		RULES.put("Rock Rock", -1);
		RULES.put("Paper Rock",1);
		RULES.put("Paper Scissors",0);
		RULES.put("Paper Lizard",0);
		RULES.put("Paper Spock",1);
		RULES.put("Paper Paper",-1);
		RULES.put("Scissors Rock",0);
		RULES.put("Scissors Paper",1);
		RULES.put("Scissors Lizard",1);
		RULES.put("Scissors Spock",0);
		RULES.put("Scissors Scissors",-1);
		RULES.put("Lizard Rock",0);
		RULES.put("Lizard Paper",1);
		RULES.put("Lizard Scissors",0);
		RULES.put("Lizard Spock",1);
		RULES.put("Lizard Lizard",-1);
		RULES.put("Spock Rock",1);
		RULES.put("Spock Paper",0);
		RULES.put("Spock Scissors",1);
		RULES.put("Spock Lizard",0);
		RULES.put("Spock Spock",-1);
		
		Map<String,String> OUTCOMES = new HashMap<String, String>();
		//simple lookup based on on possible inputs mapping outcomes to choices based on the rules
		OUTCOMES.put("Rock Paper", "Paper covers Rock");
		OUTCOMES.put("Rock Scissors", "Rock crushes Scissors");
		OUTCOMES.put("Rock Lizard", "Rock crushes Lizard");
		OUTCOMES.put("Rock Spock", "Spock vaporizes Rock");
		OUTCOMES.put("Rock Rock", "");
		OUTCOMES.put("Paper Rock","Paper covers Rock");
		OUTCOMES.put("Paper Scissors","Scissors cuts Paper");
		OUTCOMES.put("Paper Lizard","Lizard eats Paper");
		OUTCOMES.put("Paper Spock","Paper disproves Spock");
		OUTCOMES.put("Paper Paper","");
		OUTCOMES.put("Scissors Rock","Rock crushes Scissors");
		OUTCOMES.put("Scissors Paper","Scissors cuts Paper");
		OUTCOMES.put("Scissors Lizard","Scissors decapitates Lizard");
		OUTCOMES.put("Scissors Spock","Spock smashes Scissors");
		OUTCOMES.put("Scissors Scissors","");
		OUTCOMES.put("Lizard Rock","Rock crushes Lizard");
		OUTCOMES.put("Lizard Paper","Lizard eats Paper");
		OUTCOMES.put("Lizard Scissors","Scissors decapitates Lizard");
		OUTCOMES.put("Lizard Spock","Lizard poions Spock");
		OUTCOMES.put("Lizard Lizard","");
		OUTCOMES.put("Spock Rock","Spock vaporizes Rock");
		OUTCOMES.put("Spock Paper","Paper disproves Spock");
		OUTCOMES.put("Spock Scissors","Spock smashes Scissors");
		OUTCOMES.put("Spock Lizard","Lizard poions Spock");
		OUTCOMES.put("Spock Spock","");
		
		//PROCESS THE DATA
		for(String fight:lines){//don't have to use a loop here since the problem specifies only one input, but for testing purposes this was easier (could test all at once)
			String[] choices = fight.split(" ");
			if (RULES.get(fight)==1){
				System.out.print(choices[0].toUpperCase()+" WINS, ");
			}
			else if (RULES.get(fight)==0){
				System.out.print(choices[0].toUpperCase()+" LOSES, ");
			}
			else{
				System.out.println("TIE, "+choices[0].toUpperCase() + " does not effect " + choices[0].toUpperCase());
			}
			if (!choices[0].equals(choices[1])){
				System.out.println(OUTCOMES.get(fight));
			}
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
