import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.SortedSet;
import java.util.TreeSet;
/**
 * PROBLEM: Insta-where?
 * DIFFICULTY LEVEL: MEDIUM-HIGH
 * ESTIMATED COMPLETION TIME NEEDED: 15-25 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-22
 * WHAT IT TESTS: 
 * 	1.) Ability to pull multiple data groups out of a single file, and handle them separately
 * 	2.) Ability to deal with imperfections in the data (text files often introduce issues such as unwanted whitespace characters)
 * 	3.) Ability to cross-map data across multiple data groups to get from a point A to a desired point D of information
 * 	4.) Ability to group and sort the output data according to a very specific set of implementation logic rules
 *  5.) Ability to handle unknowns/errors gracefully
 * 	6.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * Good news, you got a job at Instagram right out of college!
 * Bad news, your very first assignment requires that you work with a data file with less-than-perfect data sources.
 * 
 * You need to create a process to figure out a list of user's countries based on their recorded GPS coordinates.
 * 
 * The data file you will be using is in the format of:
 * 
 * 	Users List
 * 	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * 	Country List
 * 
 * The "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" marks a data region change.
 * 
 * You'll need to cross-reference each user's location against the official Instagram country list which will be in the form of: 
 * 
 * 	Name|(x.xx,y.yy)
 * 
 * 	Example:
 * 	Mara Jade-Skywalker|(3.33,6.91)
 * 
 * The country list will be in the form of:
 * 
 * 	Country Name:	(x1,y1);(x2,y2);(x3,y3);(x4,y4)
 * 
 * 	Example:
 * 	Japan:			(45,8);(46,8);(45,11);(46,11)
 * 
 * If the user's location was unknown, their coordinates will be (-100,-100). If a user's country can't be found, simply list those users under "Unknown".
 * 
 * A user's location will be considered to be "inside" a country if the rectangle defined by the coordinates of the country contains the point, or the point is on the border of the rectangle (which includes the corners).
 * 
 * Once you have determined the country each user should belong to (or that it is unknown) output an alphabetized list of the countries, with the users listed under their country (do not list countries with no users). Put any "unknowns" at the end/bottom of the list.
 * 
 * You DO NOT need to alphabetize the list of users listed under each country.
 * 
 * ## Sample (Abbreviated) Input
 * 
 * 	Mara Jade-Skywalker|(45.01,9.01)
 * 	~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * 	Japan:		(45,8);(46,8);(45,11);(46,11)
 * 	USA:		(1,6);(9,6);(1,12);(9,12)
 * 
 * ## Sample Output
 * 	[Japan]
 * 	-Mara Jade-Skywalker
 * */
public class prob22 {
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * Student data all share the same map coordinates, user locations and names change per data set
	 * 1.) Tests all edge cases: unknown users, not found users, users in subregions, and users in regular locations
	 * 2.) Tests only users located in S.America, and Africa and one not-found user
	 * 3.) Tests only users found in Europe and Asia
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * Judge data all share the same map coordinates (different from students: shifted "up" by 100) 
	 *  user locations and names change per data set
	 * 1.) One Ukrainian, one Russian, one Japanese person, one North Korean, one Australian, and one Mexican
	 * 2.) Only unknown (fictional) users
	 * 3.) Only (fictional) users in countries that start with A ,V or C, no unknowns or not-founds, all locations are either corners or edges
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * Major pain points in this problem will be the multiple data sets, and the fact that there
	 * is no clear path from start to finish to get all of the needed data. Also causing pain will 
	 * be detecting where a point is contained on a rectangle (which includes
	 * the edges and corners, which many built-in algorithms exclude. The sorting may also cause 
	 * problems with people, depending on how they implement their solution and how familiar they 
	 * are with sorting.
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			runP10_GPS();
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results.
	 * */
	private static void runP10_GPS() {
		List<String> countries =new ArrayList<String>();
		//PARSE THE DATA IN
		//production
		List<String> people = readFromFileInputByCommandLine(countries,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
		//debugging
		//List<String> people = readFromFileToArrayList("C:\\CodeWars2019\\probAM-GPS-ISO-Lang-Codes-For-Instagram-McAdams\\probAM-student-1-in.txt",countries,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"); 
		//PROCESS THE DATA
		//parse the country data into a list
		Map<String,Rectangle> country_coords = parseCountryList(countries);
		printResult(parsePeople(people,country_coords));
	}
	/**
	 * Takes a list of coordinates and translates that into a rectangle
	 * Expected input: coordinates = (N,N);(N,N);(N,N);(N,N) where N= an integer
	 * Each coordinate is expected to be semi-colon delimited
	 * The parenthesis and comma of a string depiction of a coordinate are also expected 
	 * (the parenthesis are not strictly required, the comma delimiter is)
	 * */
	private static Rectangle RectangleFromCoords(String coordinates){
		Rectangle result = null;
		List<Point> points = new ArrayList<Point>();
		String[] coordsRaw = coordinates.trim().split(";");
		if (coordsRaw.length ==4)
		{
			for(int i=0;i<coordsRaw.length;i++){
				String coords[] = coordsRaw[i].replace("(", "").replace(")", "").trim().split(",");
				if (coords.length > 1){
					points.add(new Point(Integer.parseInt(coords[0]),Integer.parseInt(coords[1])));
				}
				else{
					break;
				}
			}
			if (points.size() == 4){
				double lowestX = -1;
				double lowestY = -1;
				for(Point p:points){
					if (p.getX() < lowestX || lowestX == -1){
						lowestX = p.getX(); 
					}
					if (p.getY() < lowestY || lowestY == -1){
						lowestY = p.getY(); 
					}
				}
				Point upperLeft = null;
				for(Point p:points){
					if (p.getX() == lowestX && p.getY() == lowestY){
						upperLeft = p;
						break;
					}
				}
				Point upperRight = new Point((int)upperLeft.getX(),(int)upperLeft.getY());//automatically takes care of "single point" countries
				Point lowerLeft = new Point((int)upperLeft.getX(),(int)upperLeft.getY());
				for(Point p:points){
					if (p.getX() == upperLeft.getX() && p.getY() != upperLeft.getY()){
						lowerLeft = p;
					}
					else if (p.getX() != upperLeft.getX() && p.getY() == upperLeft.getY()){
						upperRight = p;
					} 
				}
				int width = (int)upperLeft.distance(upperRight);
				int height = (int)upperLeft.distance(lowerLeft);
				result = new Rectangle(upperLeft,new Dimension(width,height));
			}
			else{
				result = new Rectangle(0,0,0,0);
			}
		}
		else{
			result = new Rectangle(0,0,0,0);
		}
		return result;
	}
	/**
	 * Takes a list of lines representing country names and their boundary
	 * coordinates and parses them into a hashmap with a key on the country
	 * name, and a rectangle constructed out of the coordinates. Also
	 * handles "single point" countries where all 4 coordinates are the same.
	 * 
	 * Expected input: Country Name: (N,N);(N,N);(N,N);(N,N) where N= an integer
	 * */
	private static Map<String,Rectangle> parseCountryList(List<String> countries){
		Map<String,Rectangle> result = new HashMap<String, Rectangle>();
		try{
			for(String c:countries){
				String[] data = c.trim().split(":");
				if (data.length > 1)
				{
					String key = data[0].trim();
					Rectangle val = RectangleFromCoords(data[1].trim());//upper left coord x, y, width, height
					if (!result.containsKey(key)){
						result.put(key, val);
					}
				}
			}
		}
		catch (Exception ex){
			System.out.println(ex.getMessage());
		}
		return result;
	}
	/**
	 * Takes a list of lines representing the people who have signed up for new
	 * user accounts and parses them into a hashmap keyed on the Country+Language
	 * code found for the user with their name as the value (formatted for output).
	 * 
	 * Uses the previously parsed hashmaps for countries, languages, and language
	 * mapping at the country and subregion level to determine where the user
	 * should be categorized.
	 * 
	 * Expected input: Mara Jade-Skywalker|(3.33,6.91) (along with the hash maps for
	 * country coordinates, languages codes, country-language code associations, and
	 * country subregion-language code associations.
	 * */
	private static Map<String,String> parsePeople(List<String> people,Map<String,Rectangle> country_coords){
		Map<String,String> result = new HashMap<String, String>();
		try{
			for(String p:people){
				String[] person = p.trim().split("\\|");//pipe is interpreted as a regex here in Java to split every character, need to escape it to a literal
				String CountryName = "";
				//determine where they are located
				if (person.length > 1){
					String coords[] = person[1].replace("(", "").replace(")", "").trim().split(",");
					Point2D loc = new Point2D.Double(Double.parseDouble(coords[0]),Double.parseDouble(coords[1]));
					for (Map.Entry<String,Rectangle> _country : country_coords.entrySet()) {
						Rectangle country = _country.getValue();
						Point2D  lowerLeft = new Point2D.Double((double)country.getLocation().getX(),(double)country.getLocation().getY()+country.height);
						Point2D  upperRight = new Point2D.Double((double)country.getLocation().getX()+country.width,(double)country.getLocation().getY());
						Point2D  lowerRight = new Point2D.Double((double)country.getLocation().getX()+country.width,(double)country.getLocation().getY()+country.height);
						if (country.contains(loc.getX(),loc.getY()) || 
							country.getLocation().equals(loc) ||
							lowerLeft.equals(loc)|| 
							upperRight.equals(loc)|| 
							lowerRight.equals(loc))
						{
							//pull their country from their location
							CountryName = _country.getKey();
							break;
						}
					}
					if (CountryName.equals("")){
						String outputKey = "Unknown";
						if (result.containsKey(outputKey)){
							String peopleList = result.get(outputKey);
							result.replace(outputKey, peopleList+"\n-"+person[0].trim());
						}
						else{
							result.put(outputKey, person[0].trim());
						}
					}
					else{
						//take the main/first language
						String outputKey = CountryName;
						if (result.containsKey(outputKey)){
							String peopleList = result.get(outputKey);
							result.replace(outputKey, peopleList+"\n-"+person[0].trim());
						}
						else{
							result.put(outputKey, person[0].trim());
						}
					}
				}
				else{
					System.out.println("Error expected length of people data line was not met");
				}
			}
		}
		catch (Exception ex){
			System.out.println(ex.getMessage());
		}
		return result;
	}
	/**
	 * Takes the hashmap of output for people (already grouped and categorized by
	 * country and language code), and the hashmap for the language codes themselves
	 * and outputs the final results in the sorted order of country name then
	 * language name in ascending order, with the the group of each user under 
	 * each country+language grouping in the format of:
	 * 
	 * [Country1]
	 * -Language Name
	 * --Person Name
	 * [Country2]
	 * -Language Name
	 * --Person Name
	 * 
	 * Expected input:	hashmap of grouped and categorized people under their country+language codes
	 * 					hashmap of language codes mapped to the language names
	 * */
	private static void printResult(Map<String,String> output){
		SortedSet<String> keys = new TreeSet<>(output.keySet());
		List<String> countriesOutput = new ArrayList<String>();
		String outputUnknownToEnd = "";
		for (String key : keys) {
			String[] header = key.split("\\+");//+ is interpreted as a regex meta character in Java, need to escape it to a literal
			if (!countriesOutput.contains(header[0])){
				System.out.println("["+header[0]+"]");
				countriesOutput.add(header[0]);
			}
			System.out.println("-"+output.get(key));
		}
		System.out.print(outputUnknownToEnd);
	}
	/**
	 * Modification to standard input code to allow for splitting the data file up into different lists based on a section delimiter
	 * */
	private static List<String> readFromFileInputByCommandLine(List<String> countries, String sectionBreak) {
		List<String> defaultResult = new ArrayList<String>();// requires java.util.*
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		int regionsSeen = 0;
		int isoLinesSeen = 0;
		for(String line:lines){
			if (line.trim().equals(sectionBreak))
			{
				++regionsSeen;
				continue;
			}
			if (regionsSeen == 0){
				defaultResult.add(line);
			}
			else if (regionsSeen ==1){
				countries.add(line);
			}
		}
		//iso.add("zzz,Unknown");//allow easily outputting Unknown Country/Language
		return defaultResult;
	}
	/**
	 * Modification to file input code to allow for splitting the data file up into different lists based on a section delimiter
	 * */
	private static List<String> readFromFileToArrayList(String filePath,List<String> countries, String sectionBreak) {
		List<String> defaultResult = new ArrayList<String>();// requires java.util.*
		List<String> lines = new ArrayList<String>();
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		int regionsSeen = 0;
		int isoLinesSeen = 0;
		for(String line:lines){
			if (line.trim().equals(sectionBreak))
			{
				++regionsSeen;
				continue;
			}
			if (regionsSeen == 0){
				defaultResult.add(line);
			}
			else if (regionsSeen ==1){
				countries.add(line);
			}
		}
		//iso.add("zzz,Unknown");//allow easily outputting Unknown Country/Language
		return defaultResult;
	}
}
