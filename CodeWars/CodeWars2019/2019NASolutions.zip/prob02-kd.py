#!/usr/bin/env python3

import sys

line = sys.stdin.readline()

(H, M, S) = list(map(int, line.split()))

print(H, " ", M, " ", S, ". ", end="", sep="")
if (H*S >= M):
    print("I will make it!")
else:
    print("I will be late!")