import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 * PROBLEM: Get your homework in!
 * DIFFICULTY LEVEL: MEDIUM
 * ESTIMATED COMPLETION TIME NEEDED: 15-20 minutes
 * AUTHOR: Robert McAdams, mcadams@hpe.com, 1-916-240-0615
 * LAST MODIFIED: 2019-02-19
 * WHAT IT TESTS: 
 * 	1.) Ability to move back and forth from ASCII values to characters
 * 	2.) Ability to translate ASCII characters to hexadecimal values
 * 	3.) Ability to create an algorithm with multiple branching paths based on implementation logic
 * 	4.) Ability to understand and program solutions for intermediate programming concepts such as order of operations, keeping track of data, splitting a string, formatting output, implementing algorithms.
 *  
 * PROBLEM DESCRIPTION: 
 * The airport has a content filter for content, and it is blocking your attempts to reach your
 * school's VPN in order to submit your last assignment by the deadline before you board your plane.
 * However, you have figured out that their filter is very literal, and won't block content it doesn't 
 * understand. So you need to write a quick program to defeat the airport's content filter to allow you
 * to connect to your school's VPN.
 * 
 * You will need to modify your VPN connection string to do this.
 * 
 * You have determined that a "double-URL encoding" will get past the airport's filters, because the
 * airport is interpolating URL-encoding (from UTF-8 ASCII) and blocking it, but your school's VPN 
 * understands "double-URL encoding."
 * 
 * A URL-encoded string (also known as "percent encoding") normally would change this address:
 * https://example.com:8080/schoolVPN?startConnection=begin!&schoolName=Jedi Academy&ConnectOn=Number=#3
 * &username=Luke Skywalker&password=who invited all these EWOKS?!
 * to:
 * https://example.com:8080/schoolVPN?startConnection=begin%21&schoolName=Jedi%20Academy&ConnectOn=Number%23%3D3
 * &username%3DLuke%20Skywalker%26password%3Dwho%20invited%20all%20these%20EWOKS%3F%21
 * 
 * Normal (web browser readable) URL encoding only changes the query string, which will be all content after 
 * the first question mark in the URL. While URL-encoding exists for all ASCII characters, generally only 
 * non-numbers and non-(ASCII)letters get encoded (along with spaces).
 * That leaves the URL in a browser-readable format.
 * 
 * However, to get around the airport filtering and connect to your school's VPN, you will need to further
 * encode it to replace all percent signs (%) with the character sequence: 0x25 which is the hex 
 * representation of the percent sign your school's VPN understands. You will also need to encode all 
 * characters which are not letters or numbers, to URL-encoded escape characters.
 * 
 * SPECIAL NOTE: you will need to leave the actual domain name and port un-encoded though. The domain
 * name will be everything after https:// and before the next slash (/). The port will follow the domain
 * name after a colon, giving the port number, also before the next slash (/).
 * 
 * You are guaranteed that the URL will be given in the form of:
 * https://DOMAIN(:port)/(something)?query
 * Where the parts in parenthesis are optional.
 * 
 * Example 1: https://hpe.com:443/powerChord?E=5&A=7&D=7
 * The domain is: hpe.com, and the port is 443, so you would leave hpe.com:443 alone 
 * 
 * Example 2: https://hp.com:8080/?something=1&somethingElse=2
 * The domain is: hp.com, and the port is 8080, so you would leave hp.com:8080 alone 
 * 
 * Full example:
 * Given:
 * https://example.com:8080/schoolVPN?startConnection=begin!&schoolName=Jedi Academy&ConnectOn=Number=#3
 * &username=Luke Skywalker&password=who invited all these EWOKS?!
 * 
 * Your code would need to change it to:
 * https0x253a0x252f0x252fexample.com:80800x252fschoolVPN0x253fstartConnection0x253dbegin0x2521
 * 0x2526schoolName0x253dJedi0x2520Academy0x2526ConnectOn0x253dNumber0x253d0x252330x2526username0x253dLuke0x2520Skywalker
 * 0x2526password0x253dwho0x2520invited0x2520all0x2520these0x2520EWOKS0x253f0x2521
 * 
 * URL encoding (from UTF-8) takes the 2-character HEX value of an ASCII character, and prefixes it with a percent (%) symbol.
 * For example, a space character is %20 when URL-encoded, and the tilde (~) character is %7E when URL-encoded.
 * 
 * (Unicode is being specifically excluded from this problem, as it adds an additional layer of complexity 
 * (namely that UTF-8 url-encoded values are double-values))
 * */
public class prob24 {
	private static char ASCII_PERIOD = 46;
	private static char ASCII_SLASH = 47;
	private static char ASCII_ZERO = 48;
	private static char ASCII_NINE = 57;
	private static char ASCII_COLON = 58;
	private static char ASCII_CAPA = 65;
	private static char ASCII_CAPZ = 90;
	private static char ASCII_LOWA = 97;
	private static char ASCII_LOWZ = 122;
	/** SOLUTION:
	 * -----------------------------------------------------------------------------------------
	 * STUDENT DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Tests all aspects of the required encoding logic, including optional port number
	 * 2.) Again tests all aspects of the required encoding logic, including optional port number
	 * 3.) Again tests all aspects of the required encoding logic, but not the optional port number
	 * -----------------------------------------------------------------------------------------
	 * JUDGE DATA:
	 * -----------------------------------------------------------------------------------------
	 * 1.) Tests the majority of the special character encodings, and uses the optional port
	 * 2.) Tests using spaces mixed with special characters and non-encoded characters, and uses the optional port
	 * 3.) Does not use optional port, includes almost entirely only non-encoded characters 
	 * -----------------------------------------------------------------------------------------
	 * NOTES:
	 * 
	 * The solution provided only uses libraries found in the standard Java Developer Kit (JDK), 
	 * no external modules or 3rd party libraries are used.
	 * */
	public static void main(String[] args) {
		try
		{
			runP6_URLEncode();
			System.exit(0);
		}
		catch (Exception e)
		{
			System.out.println("error: "+e.getMessage());	
		}
	}
	/**
	 * Parses all the data, implements the program logic, and calls the functions
	 * to output the results.
	 * */
	private static void runP6_URLEncode(){
		//PARSE THE DATA IN
		//production
		List<String> lines = readFromFileInputByCommandLine();
		//debugging
		//List<String> lines = readFromFileToArrayList("C:\\CodeWars2019\\probAI-judge-3-in.txt"); 
		//PROCESS THE DATA
		String input = lines.get(0);
		List<String> output = new ArrayList<String>();
		int slashCount = 0;
		for (int i=0; i<input.length();i++)
		{
			char c = input.charAt(i);
			if ((c>=ASCII_ZERO && c<=ASCII_NINE) || (c>=ASCII_CAPA && c<=ASCII_CAPZ)|| (c>=ASCII_LOWA && c<=ASCII_LOWZ))
			{
				output.add(""+c);
			}
			else
			{
				if (slashCount < 3)
				{
					if ((c == ASCII_COLON && slashCount == 0)||(c != ASCII_PERIOD && c != ASCII_COLON))
					{
						output.add("0x25"+Integer.toHexString(c));
					}
					else
					{
						output.add(""+c);	
					}						
				}
				else
				{
					output.add("0x25"+Integer.toHexString(c));
				}
			}
			if (c == ASCII_SLASH)
			{
				slashCount++;
			}
		}
		for(String s:output)
		{
			System.out.print(s);
		}
	}
	private static List<String> readFromFileInputByCommandLine() {
		List<String> lines = new ArrayList<String>();//requires java.util.*
		Scanner input = new Scanner(System.in);
		try
		{
			while (input.hasNext())
			{
				String line = input.nextLine();
				lines.add(line);
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		finally
		{
			input.close();			
		}
		return lines;
	}
	private static List<String> readFromFileToArrayList(String filePath) {
		List<String> lines = new ArrayList<String>();// requires java.util.*
		FileInputStream fis = null;
		int i = 0;// holds the remaining bytes to read
		char c;// placeholder character holder
		char CR = (char) 13;// -> \r
		char LF = (char) 10;// -> \n
		try {
			fis = new FileInputStream(filePath);
			String line = "";
			while ((i = fis.read()) != -1) {
				c = (char) i;
				if (c != CR) {// if the character is the \r character, we are at the end of the line
					if (c != LF) {// non-Linux based file systems (like Windows) will add the new line (line feed)
								  // character as well, ignoring this
						line += c;
					}
				} else {
					lines.add(line);
					line = "";
				}
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (fis != null) {
				try
				{
					fis.close();
				}
				catch (Exception ex)
				{
					ex.printStackTrace();
				}
			}
		}
		return lines;
	}
}
