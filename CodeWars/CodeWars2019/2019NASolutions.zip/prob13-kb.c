#include <stdio.h>
#include <stdlib.h>
#define NUMS 4

int main(argc, argv) int argc; char **argv; {
char buf[80];
double n[NUMS];
int i;
int j;

for(i=0;i<NUMS;i++) {
 scanf("%s",(char *)&buf);
 if(buf[0]=='X')
  j=i;
 else
  sscanf(buf,"%lf",&n[i]);
}
switch(j) {
 case 0: printf("%.1f\n",n[1]*n[2]/n[3]); break;
 case 1: printf("%.1f\n",n[0]*n[3]/n[2]); break;
 case 2: printf("%.1f\n",n[0]*n[3]/n[1]); break;
 case 3: printf("%.1f\n",n[1]*n[2]/n[0]); break;
}
}
