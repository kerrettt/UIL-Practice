#include <stdio.h>
#include <stdlib.h>

#define MAX 80
int main(argc, argv) int argc; char **argv; {
char s[MAX][MAX];
int i,j,k;
int c,r;
char p;
for(i=0;i<MAX;i++) s[i][0]='\0';
for(scanf("%d %d",&c,&r),i=r;i>0;i--) {
 scanf("%d",&j);
 for(k=0;(s[j][k]=getchar())!='\n';k++);
 s[j][k]='\0';
 }
for(i=r-1;i>=0;i--)
 printf("%d %s\n",i,s[i]);
printf("  ");
for(i=0;i<c;i++)
 printf("%1d",i%10);
printf("\n");

}
