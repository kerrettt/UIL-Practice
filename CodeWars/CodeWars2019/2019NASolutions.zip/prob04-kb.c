#include <stdio.h>
#include <stdlib.h>

int main(argc, argv) int argc; char **argv; {
int n;
double amt,tax;
for(scanf("%d",&n);n>0;n--) {
	scanf("%lf",&tax);
	scanf("%lf",&amt);
        tax/=100;
	printf("On your $%.2f purchase, the tax amount is $%.2f\n",amt,(tax * amt)/(1.0 + tax));
 }
}
