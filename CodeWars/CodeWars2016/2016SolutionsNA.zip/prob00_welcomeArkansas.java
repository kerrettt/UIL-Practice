public class prob00 {

    public static void main(String[] args) {
        System.out.println("Arkansas, The Natural State!");
    }
}
